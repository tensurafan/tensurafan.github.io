from collections import namedtuple
from dataclasses import dataclass, field
from pathlib import Path

from logzero import logger


@dataclass
class File:
    """
    A file.
    """

    path: Path
    content: str = ""
    init_read: bool = True

    def __post_init__(self):
        # Read the file if it exists.
        if self.path.is_file() and self.init_read:
            self.content = self.path.read_text()

    def write_as(self, path: Path):
        """
        Write the file to the given path.
        """
        path.write_text(self.content)


@dataclass
class FileBinder:
    """
    A class to hold all the files.
    """

    master: File = None
    sections: list[File] = field(default_factory=list)

    def dump(self, dump_dir: Path):
        """
        Dump all the files to the given directory.

        :param dump_dir: The directory to dump the files to.
        """
        dump_dir.mkdir(parents=True, exist_ok=True)

        for section in self.sections:
            section.write_as((dump_dir / section.path.name).with_suffix(".xhtml"))
            logger.info(f"Dumped {section.path.stem}.xhtml")

    def merge_all(self) -> str:
        """
        Merge all the files into one big string.
        Exclude the master file.

        :return: The merged string.
        """

        return "\n\n".join([section.content for section in self.sections])


# Terms extracted from the terms.json format.
Term = namedtuple("Term", ["term", "case_sensitive"])
