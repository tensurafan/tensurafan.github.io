import sys
from pathlib import Path

import docx  # Using pypi package python-docx
from logzero import logger

import slime_builder.cli as cli


def pack(base_dir: Path):
    """
    Convert all extension-less files to docx by pasting the raw text into a
    docx file.

    :param base_dir: The base directory to convert.
    """

    # Ensure the dir exists.
    if not base_dir.is_dir():
        logger.critical(f"{base_dir} does not exist.")
        sys.exit(1)

    # Save the docx files in /docx:
    docx_dir = base_dir / "docx"
    # Ensure it's empty.
    if docx_dir.exists():
        if not cli.ask_then_delete(docx_dir):
            sys.exit(1)

    convert_all_in_dir(base_dir, docx_dir)


# =============================================== Internal Functions ================================================= #


# Ignore that docx.shared erroneously can't be found.
# noinspection PyUnresolvedReferences
def text_to_docx(text: str) -> docx.Document:
    """
    Convert the text to a docx file.

    :param text: The text to convert.
    :return: The docx file.
    """
    doc = docx.Document()
    # Use font size 11, Times New Roman
    # 1.5 line spacing, no space after paragraph.
    # A4 paper, 2cm margins all around.
    # Set proofing language to English (US).
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Times New Roman"
    font.size = docx.shared.Pt(11)
    paragraph_format = style.paragraph_format
    paragraph_format.line_spacing = 1.5
    paragraph_format.space_after = docx.shared.Pt(0)
    sections = doc.sections
    for section in sections:
        section.top_margin = docx.shared.Cm(2)
        section.bottom_margin = docx.shared.Cm(2)
        section.left_margin = docx.shared.Cm(2)
        section.right_margin = docx.shared.Cm(2)
        section.page_height = docx.shared.Cm(29.7)
        section.page_width = docx.shared.Cm(21)
    doc.core_properties.language = "en-US"

    # Add each line as a paragraph.
    for line in text.splitlines():
        doc.add_paragraph(line)

    return doc


def gather_all_text_files(base_dir: Path) -> list[Path]:
    """
    Gather all text files in the base directory that do not have an extension.

    :param base_dir: The base directory containing the text files.
    :return: A list of text files.
    """
    return [
        f for f in base_dir.glob("*") if f.is_file() and not f.suffix and not f.name.startswith(".")
    ]


def convert_all_in_dir(base_dir: Path, docx_dir: Path):
    """
    Gather all text files in the base directory and convert them to docx.

    :param base_dir: The base directory containing the text files.
    :param docx_dir: The directory to save the docx files in.
    """
    text_files = gather_all_text_files(base_dir)
    for f in text_files:
        logger.info(f"Found {f.name}")

    docx_files = (text_to_docx(f.read_text()) for f in text_files)

    docx_dir.mkdir(exist_ok=True)
    for docx_file, f in zip(docx_files, text_files):
        docx_file.save(docx_dir / (f.name + ".docx"))
