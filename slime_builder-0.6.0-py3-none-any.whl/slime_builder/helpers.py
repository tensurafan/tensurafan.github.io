import difflib
from pathlib import Path
import re

import freetype  # Actually freetype-py
from PIL import Image
from colour import Color
from logzero import logger

FONT_SIZE = 12


def f_plural(value, singular: str, plural: str):
    """
    Selects which form to use based on the value.
    """
    return singular if value == 1 else plural


def closest_match(word: str, choices: list[str]) -> str | None:
    """
    Return the closest match for the given word in the list of choices.
    If no good match is found, return None.
    """
    if word in choices:
        return word
    else:
        # Find the closest match using difflib:
        closest = difflib.get_close_matches(word, choices, 1, 0.5)  # 0.6 is the default threshold
        if closest:
            return str(closest[0])
        else:
            return None


class OneTimeBool:
    """
    This class is used to make sure that a certain action is only performed once
    for the lifetime of the object.
    """

    def __init__(self):
        self.first_time = True

    def __bool__(self):
        if self.first_time:
            self.first_time = False
            return True
        else:
            return False


def chapter_name_to_ref(name: str) -> str:
    """
    Convert a chapter name to a reference.
    If there is a colon, only use what's before it.

    :param name: The chapter name.

    :return: The reference.
    """
    return name.split(":")[0].strip().lower().replace(" ", "-")


def smart_path(base_dir: Path, preferred_dir: str, fallback_dir: str, file_name: str) -> str:
    """
    Check if the file is in the preferred directory,
    using the following file extensions in order:
    - (no change)
    - .png
    - .jpg
    - .jpeg

    If unsuccessful, try the same in the fallback directory.
    If that fails, log an error and return an erroneous path,
    assuming the file was in the preferred directory.

    :param base_dir: The base directory.
    :param preferred_dir: The preferred directory.
    :param fallback_dir: The fallback directory.
    :param file_name: The file name.

    :return: The path to the file.
    """
    suffixes = ("", ".png", ".jpg", ".jpeg")
    file_name_path = Path(file_name)

    for ext in suffixes:
        file_path = base_dir / preferred_dir / file_name_path.with_suffix(ext)
        if file_path.is_file():
            return f"{preferred_dir}/{file_name_path.with_suffix(ext).name}"

    for ext in suffixes:
        file_path = base_dir / fallback_dir / file_name_path.with_suffix(ext)
        if file_path.is_file():
            return f"{fallback_dir}/{file_name_path.with_suffix(ext).name}"

    logger.error(f"Could not find file: {file_name}")
    return f"{preferred_dir}/{file_name}"


def check_image_suffixes(path: Path) -> Path | None:
    """
    Check all supported image suffixes to see if this path is an image file.

    :param path: The path to check (may or may not have a suffix already).
    :return: The path if successful, else None.
    """
    suffixes = ("", ".png", ".jpg", ".jpeg")

    for ext in suffixes:
        path = path.with_suffix(ext)
        if path.is_file():
            return path
    return None


def adjust_color(color: str | None, *, light: bool) -> str:
    """
    Adjust the color to be lighter or darker.

    :param color: the color to use for the theme.
    :param light: whether to lighten or darken the color.
    """
    if color is None:
        color = "32629c" if light else "6594cd"  # Default colors.
    else:
        color_obj = Color("#" + color)
        color_obj.saturation = min(0.5, color_obj.saturation)
        color_obj.luminance = 0.3 if light else 0.7
        color = color_obj.hex_l[1:]  # Remove the leading #.
    return color


def get_endcard_color(dir_src: Path, image_dir: str, endcard_file_name: str) -> str | None:
    """
    Try to find the end card among the illustrations.
    The end card must have the file name ENDCARD_FILE_NAME.
    These end card images are mostly one color, but may have artifacts along the edges,
    as well as text in the middle.
    If the end card is found, return the color at a magic pixel, x=half width, y=quarter height.

    :param dir_src: The base directory of the project.
    :param image_dir: The directory where the illustrations are stored.
    :param endcard_file_name: The file name of the end card.
    :return: Hex string of the color (e.g. "220044", if found. Else None.
    """

    image_dir = dir_src / image_dir
    # Try to find a file with the stem ENDCARD_FILE_NAME, because the file extension may vary.
    for file in image_dir.iterdir():
        if file.stem == endcard_file_name:
            image = Image.open(file)
            break
    else:
        logger.warning(f"Could not find the end card image: {endcard_file_name}.")
        return None

    color = image.getpixel((image.width // 2, image.height // 4))
    # Convert to hex.
    color = f"{color[0]:02x}{color[1]:02x}{color[2]:02x}"
    logger.debug(f"Found end card color: {color}")

    return color


def strip_comments(markout: str) -> str:
    """
    Strip comments from the markout.

    :param markout: The markout.

    :return: The markout with comments stripped.
    """
    markout = re.sub(r"^<!--.*?-->\n", "", markout, flags=re.DOTALL | re.MULTILINE)
    markout = re.sub(r"<!--.*?-->", "", markout, flags=re.DOTALL)
    return markout


def arcane_formula_for_text_width(string: str, font_path: str) -> float:
    """
    Find the display width in pixels of a string given a font, point size and DPI.

    :return: The width in cm.
    """
    # https://gist.github.com/13rac1/7e0b5fb32939685ea44e1a713aac081b
    # Uses Freetype Python bindings:http://freetype-py.readthedocs.io/en/latest/
    # Based on the FreeType Tutorial examples:
    # https://www.freetype.org/freetype2/docs/tutorial/step2.html
    # Note: This code uses bitshift by six to divide/multiply by 64 to convert
    # between 26.6 pixel format (i.e., 1/64th of pixels) and points.

    input_str = f"{string}N"
    font_point_size = FONT_SIZE
    # Freetype default is 72 DPI.
    display_dpi = 96
    # Using Open Sans, but any other font will work.
    # noinspection PyTypeChecker
    face = freetype.Face(font_path)

    # Set the point size and DPI.
    face.set_char_size(font_point_size << 6, font_point_size << 6, display_dpi, display_dpi)

    pen_x = 0
    previous_glyph = 0

    for char in input_str:
        # Convert character code to glyph index.
        glyph_index = face.get_char_index(char)

        # Retrieve kerning distance and move pen position.
        if face.has_kerning and previous_glyph and glyph_index:
            delta = face.get_kerning(previous_glyph, glyph_index)
            pen_x += delta.x >> 6

        # Load the glyph at glyph_index.
        face.load_glyph(glyph_index, freetype.FT_LOAD_FLAGS["FT_LOAD_RENDER"])

        # Dividing by 64 and increment pen position.
        pen_x += face.glyph.advance.x >> 6

        # Record current glyph index
        previous_glyph = glyph_index

    # output = "{}\nDisplayed at {}pts on a {} DPI screen is {}px wide."
    # print(output.format(input_str, font_point_size, display_dpi, pen_x))
    # print(f"The width in cm is {pen_x / 96 * 2.54:.2f}cm")
    return pen_x / display_dpi * 2.54
