"""
Provide data classes to represent and format warning or error messages.
"""

import re
import colorama as clr
from dataclasses import dataclass

# Command to find the longest word in the directory.
# $ grep -oEh "\w+" * | sort |  uniq | awk '{ print length, $0 }' | sort -n | tail -30
# Most cases should be around up to 20 characters, well below MAX_LINE_CONTEXT.
# Otherwise, searching for the nearest whitespace could kill the match.
MAX_LINE_CONTEXT = 50  # How many characters to show before and after the match.
MAX_LINE_HYSTERESIS = 200  # The minimum line length to consider trimming for.


def highlight_match(line: str, match: re.Match | tuple[int, int], color: str):
    """
    Highlight the match in the given line.
    :param match: The match to highlight.
    :param line: The line to highlight in.
    :param color: The color to highlight in. This should be a colorama color escape sequence.
    """
    underline_code = "\x1B[4m"
    # Draw the match with an underline and colored highlight.
    match_start, match_end = match.span() if isinstance(match, re.Match) else match
    return f"{line[:match_start]}{color}{underline_code}{line[match_start:match_end]}{clr.Style.RESET_ALL}{line[match_end:]}"


def trim_line(line: str, match: re.Match | tuple[int, int]):
    """
    Trim the line to show only the match and some context.
    The amount of context is determined by MAX_LINE_CONTEXT.

    :param line: The line to trim.
    :param match: The match to show.
    """
    match_start, match_end = match.span() if isinstance(match, re.Match) else match
    # If the match is too long, trim it.
    # Round to the nearest whitespace.
    if len(line) > MAX_LINE_HYSTERESIS:
        omission = f"{clr.Style.DIM}{clr.Fore.LIGHTBLACK_EX}[...]{clr.Style.RESET_ALL}"
        # If the match is too long, trim it.
        # Round to the nearest whitespace.
        if match_start > MAX_LINE_CONTEXT:
            line = line[match_start - MAX_LINE_CONTEXT :]
            line = line[line.find(" ") :]
            line = omission + line
        if match_end < len(line) - MAX_LINE_CONTEXT:
            line = line[: match_end + MAX_LINE_CONTEXT]
            line = line[: line.rfind(" ")]
            line = line + omission
    return line


@dataclass
class MoMessage:
    """
    A data class to represent a warning or error message.

    Attributes:
        message: The message to display.
        file_name: The name of the file the message is from.
        line: [Optional] The line the message is for.
        line_number: [Optional] The line number the message is for.
        re_match: [Optional] The regex match the message is for. Used to highlight the match in the line.
    """

    message: str
    file_name: str
    line: str | None = None
    line_number: int | None = None
    re_match: re.Match | tuple[int, int] | None = None
    _MESSAGE_PREFIX: str = None
    _MESSAGE_COLOR: str = None

    def __str__(self):
        """
        Return a string representation of the message.
        Show all the given information.
        """

        # Print the warning in yellow, prefixed with [W: file_name: line_number]. (line number is optional)
        prefix = f"{self._MESSAGE_COLOR}[{self._MESSAGE_PREFIX}: {self.file_name}"
        if self.line_number is not None:
            prefix += f": line {self.line_number}"
        if self.re_match is not None:
            match_start = (
                self.re_match.start() if isinstance(self.re_match, re.Match) else self.re_match[0]
            )
            prefix += f": pos {match_start}"
        prefix += f"]{clr.Style.RESET_ALL} "

        if self.line is None:
            return f"{prefix}{self.message}"

        # If we have a regex match, highlight the match in yellow.
        if self.re_match is not None:
            temp_line = highlight_match(self.line, self.re_match, self._MESSAGE_COLOR)
            temp_line = trim_line(temp_line, self.re_match)
        else:
            temp_line = self.line

        # Add gray markers to reveal leading and trailing spaces.
        l_angle = f"{clr.Style.DIM}{clr.Fore.LIGHTBLACK_EX}>{clr.Style.RESET_ALL}"
        r_angle = f"{clr.Style.DIM}{clr.Fore.LIGHTBLACK_EX}<{clr.Style.RESET_ALL}"

        temp_line = l_angle + temp_line + r_angle

        return f"{prefix}{self.message}\n{temp_line}"


@dataclass
class MoWarning(MoMessage):
    """
    A warning message in a markout file.
    """

    _MESSAGE_PREFIX: str = "W"
    _MESSAGE_COLOR: str = clr.Fore.YELLOW

    @staticmethod
    def print(
        message: str,
        file_name,
        line: str | None = None,
        line_number: int | None = None,
        re_match: re.Match | None = None,
    ):
        """
        Print a warning message.

        :param message: The warning message.
        :param file_name: The name of the file being checked.
        :param line: [Optional] The line the warning is about.
        :param line_number: [Optional] The line number of the warning.
        :param re_match: [Optional] The regex match the warning is about. Used to highlight the match in the line.
        """
        print(MoWarning(message, file_name, line, line_number, re_match))


@dataclass
class MoError(MoMessage):
    """
    An error message in a markout file.
    """

    _MESSAGE_PREFIX: str = "E"
    _MESSAGE_COLOR: str = clr.Fore.RED

    @staticmethod
    def print(
        message: str,
        file_name,
        line: str | None = None,
        line_number: int | None = None,
        re_match: re.Match | None = None,
    ):
        """
        Print an error message.

        :param message: The error message.
        :param file_name: The name of the file being checked.
        :param line: [Optional] The line the error is about.
        :param line_number: [Optional] The line number of the error.
        :param re_match: [Optional] The regex match the error is about. Used to highlight the match in the line.
        """
        print(MoError(message, file_name, line, line_number, re_match))
