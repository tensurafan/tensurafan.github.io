import re
import shutil
import sys
import zipfile
from pathlib import Path

import docx2txt
from logzero import logger

import slime_builder.cli as cli


def unpack_zip(zip_file: Path):
    """
    Unpack a zip directory downloaded from google drive, extracting the files.
    Images go in one folder, and the docx files get converted to plain text.
    This is the main entry point for this module.

    :param zip_file: The zip file to unpack.
    """

    # Ensure the file exists.
    if not zip_file.exists():
        logger.critical(f"{zip_file} does not exist.")
        sys.exit(1)

    # Ensure the zip file contains one top level directory.
    top_level_dir = get_zip_top_level_dir(zip_file)
    if top_level_dir is None:
        logger.critical(
            f"{zip_file} contains multiple top level directories. Download the entire folder as a zip."
        )
        sys.exit(1)

    # If the target directory already exists, asks to delete it (or move to trash, if supported).
    target_dir = zip_file.parent / top_level_dir
    if target_dir.exists():
        if not cli.ask_then_delete(target_dir):
            sys.exit(1)

    base_dir = extract_zip(zip_file, str(top_level_dir))
    logger.info(f"Extracted to {base_dir}")
    remove_extra_files(base_dir)
    remove_numbering_from_filenames(base_dir)
    convert_all_docx(base_dir)


# =============================================== Internal Functions ================================================= #


def get_zip_top_level_dir(zip_file: Path) -> Path | None:
    """
    Ensure the zip file contains one top level directory and get its name.
    Otherwise return None.

    :param zip_file: The zip file to check.
    :return: The top level directory name, or None.
    """

    with zipfile.ZipFile(zip_file) as z:
        top_level_dirs = {Path(p).parts[0] for p in z.namelist()}
        if len(top_level_dirs) != 1:
            return None
        return top_level_dirs.pop()


def extract_zip(zip_file: Path, extract_folder_name: str) -> Path:
    """
    Extract the zip file to the parent directory, placing files in folder called source.
    If the extraction yields a single directory, replace it with its contents.

    :param zip_file: The zip file to extract.
    :param extract_folder_name: The name of the folder to extract to, relative to the zip file's parent folder.
    :return: The subdirectory containing the extracted files.
    """

    source_dir = zip_file.parent / extract_folder_name
    # Ensure the source directory either doesn't exist or is empty.
    if source_dir.exists():
        if len(list(source_dir.glob("*"))) > 0:
            raise FileExistsError(f"{source_dir} already exists and is not empty.")

    with zipfile.ZipFile(zip_file, "r") as zip_ref:
        zip_ref.extractall(source_dir)

    # Check if the extracted directory contains a single directory.
    # If so, replace it with its contents.
    if len(list(source_dir.iterdir())) == 1 and list(source_dir.iterdir())[0].is_dir():
        # Replace the directory with its contents.
        subdir = list(source_dir.iterdir())[0]
        for f in subdir.iterdir():
            f.rename(subdir.parent / f.name)
        subdir.rmdir()

    return source_dir


def remove_extra_files(base_dir: Path):
    """
    Removes extra .docx files that start with a # or .
    And removes legacy directories.
    """

    for f in base_dir.glob("*"):
        if f.name.startswith("#") or f.name.startswith("."):
            logger.info(f"Cleaning up {f.name}")
            if f.is_dir():
                shutil.rmtree(f)
            else:
                f.unlink()

    # Remove directories that are called "legacy" or "raw", case insensitive.
    for d in base_dir.glob("*"):
        if d.is_dir() and d.name.startswith("#"):
            logger.info(f"Cleaning up {d.name}")
            shutil.rmtree(d)

    # Remove any pdf files.
    for f in base_dir.glob("*.pdf"):
        logger.info(f"Cleaning up {f.name}")
        f.unlink()


def docx_to_text(docx_file: Path) -> str:
    """
    Convert the docx file to plain text.
    Dependency inversion.

    :param docx_file: The docx file to convert.
    :return: The plain text.
    """
    text = docx2txt.process(docx_file)
    # By default, docx2txt adds a blank line between paragraphs,
    # meaning 3 blank lines between paragraphs if there was a blank line in the docx.
    # This return the output to how it looks in the docx.
    text = re.sub(r"\n\n", "\n", text)
    return text


def convert_all_docx(base_dir: Path):
    """
    Gather all docx files in the base directory and convert them to plain text.
    Save the file with no extension.

    :param base_dir: The base directory containing the docx files.
    """

    for f in base_dir.glob("*.docx"):
        logger.info(f"Converting {f.name}")
        text = docx_to_text(f)
        f.unlink()
        f.with_suffix("").write_text(text)


def remove_numbering_from_filenames(base_dir: Path):
    """
    Remove any (x) from the beginning of filenames.
    """

    for f in base_dir.glob("*"):
        if match := re.match(r"\(.+\) ?(.*)", f.name):
            f.rename(f.parent / match.group(1))
