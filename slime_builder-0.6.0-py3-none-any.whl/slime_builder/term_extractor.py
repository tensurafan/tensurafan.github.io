"""
Parse a spreadsheet to output compact JSON.
JSON output:
"""

import json
import re
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pyexcel
import pyexcel_htmlr
import pyexcel_io
import pyexcel_odsr
import pyexcel_xlsx
from logzero import logger

CLEAN_COMMENT_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.*?\n")


@dataclass
class Glossary:
    """
    A compact representation of a glossary.
    """

    terms: dict = field(default_factory=dict)
    term_official_index: dict = field(default_factory=dict)
    term_tts_index: dict = field(default_factory=dict)
    term_groups: OrderedDict = field(default_factory=OrderedDict)
    term_groups_metadata: list = field(default_factory=list)
    term_groups_last_y: int = -1


def extract_terms(spreadsheet_file: Path, output_path: Path):
    """
    Read the spreadsheet file and compile the json output.

    :param spreadsheet_file: The spreadsheet file to read.
    :param output_path: The path to write the output to.
    """

    glossary = Glossary()

    parse_glossary_file(spreadsheet_file, glossary)

    logger.info(f"{len(glossary.terms)} terms found with alternatives.")

    clean_term_groups(glossary)

    jdata = compile_json(glossary)

    try:
        with open(output_path, "w", encoding="utf-8") as outfile:
            json.dump(jdata, outfile, indent=4, ensure_ascii=False)
    except OSError as e:
        logger.error("Writing the file has failed!")
        logger.exception(e)
    else:
        logger.info(f"Terms written successfully to {output_path}")


def compile_json(glossary: Glossary) -> dict:
    # Export JSON
    entries = dict()  # Combined dict of terms and official index
    for key, value in glossary.terms.items():
        entries[key] = {
            "options": value,
            "officialTermIndex": glossary.term_official_index[key],
            "textToSpeechIndex": glossary.term_tts_index[key],
            "caseSensitive": key[0].isupper(),
        }

    jdata = dict()
    jdata["pattern"] = trie_regex_from_words(glossary.terms.keys()).pattern
    jdata["terms"] = entries
    jdata["groups"] = glossary.term_groups
    return jdata


def clean_term_groups(glossary: Glossary):
    # Remove stale links to terms that had no alternatives and purge empty groups.
    for group_name, group_list in list(glossary.term_groups.items()):
        # Validate existence of referenced terms due to the * inclusion.
        for ref in list(group_list):
            if ref not in glossary.terms.keys():
                logger.info(
                    f"{ref} referenced in group {group_name}, but not included in terms. Removing from group..."
                )
                group_list.remove(ref)

        if not group_list:
            logger.info(f"{group_name} is empty, removing group...")
            del glossary.term_groups[group_name]
            continue


def parse_glossary_file(path: Path, glossary: Glossary):
    """
    Parse an ods file into a glossary.
    Exceptions need to be handled by the caller.

    :param path: The spreadsheet file to parse.
    :param glossary: The glossary structure to write into.
    """

    workbook = pyexcel.get_book_dict(file_name=str(path))

    # Pyexcel inserts comment text into cells, which we need to remove using the comment pattern.

    for sheet in workbook.values():
        for index_y, row in enumerate(sheet):
            # logger.debug(f"Processing row {index_y} of {len(sheet)}: {row}")
            for index_x in range(len(row)):
                parse_cell(row, index_x, index_y, glossary)


def clean_cell(cell: Any) -> str | None:
    """
    Clean a cell of unwanted characters and check it's a string.
    """
    # Try to make it a string.
    try:
        cell = str(cell)
    except ValueError:
        return None

    # Remove comment text
    cell = CLEAN_COMMENT_RE.sub("", cell)

    if "ignore" in cell:
        return None

    # Remove leading and trailing whitespace
    cell = cell.strip().replace(r"\+", "+")

    # Allow padding to protect trailing whitespace.
    if cell.startswith("/") and cell.endswith("/"):
        cell = cell[1:-1]

    # Check that a tts term isn't empty.
    if cell.lower().startswith("tts:"):
        if len(cell) == 4:
            logger.warning("A TTS term was left empty.")
            return None

    if not cell:
        return None

    return cell


def read_alts(row: list) -> list[str]:
    """
    This will take the remaining slice of the row, with the first term being right after the
    default term.
    It will return the cleaned list of alternatives.

    :param row: The row to read from.
    :return: A tuple of the cleaned alternatives.
    """
    alt_terms: list[str] = []
    # Stop parsing if we hit an invalid (usually blank) cell,
    # unless this blank cell is the very first one.
    # We want to preserve the official index cell in that case.
    for index, cell in enumerate(row):
        cell = clean_cell(cell)
        if cell is None:
            if index > 0:
                break
            else:
                alt_terms.append("")
        else:
            alt_terms += cell.split("&")

    return alt_terms


def parse_cell(row: list, index_x: int, index_y: int, glossary: Glossary):
    """
    Format agnostic parsing of a cell.
    Pyexcel inserts comment text into cells, which we need to remove using the comment pattern.

    Then parse the cell into the glossary.
    Format:
        *Term OfficialAlt Alt2 Alt3...

    Where * is either # or ~ signifying the original term.
    OfficialAlt may also be - to signify that the original term is the official term.
    Alt terms may contain & to indicate that the cell contains multiple terms, separated by these &.

    :param row: The row to parse.
    :param index_x: The index of the cell to parse.
    :param index_y: The index of the row to parse.
    :param glossary: The glossary structure to write into.
    """

    cell = clean_cell(row[index_x])
    if cell is None:
        return

    if cell.startswith(("#", "~", "!")):
        parse_term(cell, row, index_x, glossary)
    elif cell.startswith("§"):
        parse_group(cell, index_x, index_y, glossary)
    elif cell.startswith("*"):
        parse_standin(cell, index_x, glossary)


def parse_term(cell: str, row: list, index_x: int, glossary: Glossary):
    default_term: str = cell[1:]
    alt_terms: list[str] = read_alts(row[index_x + 1 :])
    # The official term will be the second one by default (the default term is first).
    official_index = 1
    tts_index = 0  # Use default value unless an optimized one is available.

    # If no alts are provided, skip.
    if not alt_terms:
        return

    # Check if the official term is blank or specified as the same as the default.
    # In that case, use the default term as the official term.
    # We know that the list is not empty.
    if alt_terms[0] == "-" or alt_terms[0] == "":
        alt_terms.pop(0)
        official_index = 0

    # If we only have a single alt, which is identical to the default term, skip.
    if not alt_terms or (len(alt_terms) == 1 and alt_terms[0] == default_term):
        return

    # Check if we have text to speech alternatives.
    for index, alt in enumerate(alt_terms):
        if alt.lower().startswith("tts:"):
            alt_terms[index] = alt[4:]
            # +1 because the default term is always first, but not in the alt list.
            tts_index = index + 1

    glossary.terms[default_term] = [default_term] + alt_terms
    glossary.term_official_index[default_term] = official_index
    glossary.term_tts_index[default_term] = tts_index

    # Add to the group that is to its left
    for group in reversed(glossary.term_groups_metadata):
        if index_x >= group[1]:
            glossary.term_groups[group[0]].append(default_term)
            break
    else:
        logger.warning(f"{default_term} has no group.")


def parse_group(cell: str, index_x: int, index_y: int, glossary: Glossary):
    group = cell[1:]
    logger.debug(f"Found group {group} at {index_x}")
    glossary.term_groups[group] = []
    if index_y > glossary.term_groups_last_y:
        # Clear metadata list
        glossary.term_groups_metadata.clear()
        glossary.term_groups_last_y = index_y

    glossary.term_groups_metadata.append((group, index_x))


def parse_standin(cell: str, index_x: int, glossary: Glossary):
    # Include reference to term in this group
    default = cell[1:]
    for group in reversed(glossary.term_groups_metadata):
        if index_x >= group[1]:
            glossary.term_groups[group[0]].append(default)
            break
    else:
        logger.warning(f"{default} has no group.")


class Trie:
    """
    Regex::Trie in Python. Creates a Trie out of a list of words. The trie can be exported to a Regex pattern.
    The corresponding Regex should match much faster than a simple Regex union.
    """

    def __init__(self):
        self.data = {}

    def add(self, word):
        ref = self.data
        for char in word:
            ref[char] = char in ref and ref[char] or {}
            ref = ref[char]
        ref[""] = 1

    def dump(self):
        return self.data

    @staticmethod
    def quote(char):
        return re.escape(char)

    def _pattern(self, pData):
        data = pData
        if "" in data and len(data.keys()) == 1:
            return None

        alt = []
        cc = []
        q = 0
        for char in sorted(data.keys()):
            if isinstance(data[char], dict):
                try:
                    recurse = self._pattern(data[char])
                    alt.append(self.quote(char) + recurse)
                except:
                    cc.append(self.quote(char))
            else:
                q = 1
        cconly = not len(alt) > 0

        if len(cc) > 0:
            if len(cc) == 1:
                alt.append(cc[0])
            else:
                alt.append("[" + "".join(cc) + "]")

        if len(alt) == 1:
            result = alt[0]
        else:
            result = "(?:" + "|".join(alt) + ")"

        if q:
            if cconly:
                result += "?"
            else:
                result = f"(?:{result})?"
        return result

    def pattern(self):
        return self._pattern(self.dump())


def trie_regex_from_words(words):
    trie = Trie()
    for word in words:
        trie.add(word)
    logger.debug(f"Regex: {trie.pattern()}")
    return re.compile(trie.pattern())


def make_imports_used_so_they_dont_get_auto_removed():
    # Never call this function.
    # It purely serves to distract the linter from removing the imports,
    # so that they get included in pyinstaller builds.
    pyexcel_io.io.get_data()
    pyexcel_odsr.get_data()
    pyexcel_xls.get_data()
    pyexcel_xlsx.get_data()
    pyexcel_htmlr.get_data()
