import os
import re
import datetime
import shutil
import subprocess
import sys
from enum import Enum, auto
from importlib import resources
from pathlib import Path
from functools import partial
from concurrent.futures import ThreadPoolExecutor

from logzero import logger
from natsort import natsorted

import slime_builder.structures as st
import slime_builder.templates
from slime_builder import templates
from slime_builder.chapter_covers import generator
import slime_builder.helpers as hp
from slime_builder.html_builder.processors import get_latex_master_section


def latex_build(
    dir_src: Path,
    light_theme: bool,
    color_edition: bool,
    text_font_path: str | None,
    output_dir_name: str | None,
    latex_only: bool,
    image_dir: str,
    colored_image_dir: str,
    endcard_file_name: str,
    generate_cards: bool,
    debug: bool,
    suppress_missing_color: bool = False,
    keep_color_edition_text: bool = False,
) -> None:
    """
    Convert the markout files in the given directory to latex and build the pdf.

    :param dir_src: The directory to process.
    :param light_theme: Whether to use the light theme.
    :param color_edition: Whether to use the color edition.
    :param text_font_path: The path to the main text label font used to align list labels.
    :param output_dir_name: The name of the output directory. If not expecting output, set to None.
    :param latex_only: Whether to only generate the latex files and not build the pdf.
    :param image_dir: The directory containing the images.
    :param colored_image_dir: The directory containing the colored images.
    :param endcard_file_name: The name of the end card file.
    :param generate_cards: Whether to generate the title cards.
    :param debug: Whether to not delete the latex build directory.
    :param suppress_missing_color: When False, log a warning when attempting to
        build a color edition when there is no colored illustration folder.
    :param keep_color_edition_text: When True, keep the text only meant for the color edition,
        even when not making a color edition.
    """
    logger.debug(f"Using internal font for positioning metrics: {text_font_path}")

    # Ensure the dir exists.
    if not dir_src.is_dir():
        logger.critical(f"{dir_src} does not exist.")
        sys.exit(1)

    # Get the image directory to use.
    if color_edition:
        preferred_imgdir = colored_image_dir
    else:
        preferred_imgdir = image_dir

    # Check if the image directory exists.
    if not (dir_src / preferred_imgdir).is_dir():
        if color_edition and suppress_missing_color:
            logger.debug(
                f"Could not find the colored illustrations directory: {dir_src / preferred_imgdir}. Skipping."
            )
            return
        else:
            logger.critical(
                f"Could not find the illustrations directory: {dir_src / preferred_imgdir}."
            )
            sys.exit(1)

    # Load all the files.
    binder = st.FileBinder()
    for file in dir_src.iterdir():
        if not file.is_file():
            continue

        if file.name.startswith("."):
            # Ignore hidden files.
            continue

        if file.name == "Master":
            binder.master = st.File(file)
        elif not file.suffix:
            binder.sections.append(st.File(file))

    # Sanity check.
    if binder.master is None:
        logger.critical("No master file found.")
        sys.exit(1)
    if len(binder.sections) == 0:
        logger.critical(f"No files found in {dir_src}.")
        sys.exit(1)

    # Purge comments from all files.
    for file in [binder.master, *binder.sections]:
        if file is None:
            # Master might be none.
            continue
        file.content = hp.strip_comments(file.content)

    # Get the chapter titles.
    chapter_titles = find_chapter_titles(binder)
    chapters = "\n".join([f"    {chapter}" for chapter in natsorted(chapter_titles.values())])
    logger.info(f"Found {len(chapter_titles)} chapters: \n{chapters}")

    # Get the color of the endcard.
    endcard_color = hp.get_endcard_color(
        dir_src, image_dir=image_dir, endcard_file_name=endcard_file_name
    )

    # Generate all the chapter covers.
    generate_all_chapter_title_cards(dir_src, chapter_titles, endcard_color, generate_cards)

    # Process the files, starting with the master.
    binder.master.content = markout_to_latex_master(
        markout=binder.master.content,
        chapter_titles=chapter_titles,
        base_dir=dir_src,
        image_dir=preferred_imgdir,
        fallback_image_dir=image_dir,
        light_theme=light_theme,
        color_edition=color_edition,
        text_font_path=text_font_path,
        volume_color=endcard_color,
        keep_color_edition_text=keep_color_edition_text,
    )
    for file in binder.sections:
        file.content = markout_to_latex(
            markout=file.content,
            base_dir=dir_src,
            image_dir=preferred_imgdir,
            fallback_image_dir=image_dir,
            text_font_path=text_font_path,
        )

    # Write the files to filename.tex. If the file already exists, overwrite it.
    for file in [binder.master, *binder.sections]:
        with open(dir_src / f"{file.path.name}.tex", "w") as f:
            f.write(file.content)

    # Copy the scene break files into the project.
    insert_scene_break_images(dir_src)

    # If skipping build, we are already done.
    if latex_only:
        logger.info(f"Built latex files for {dir_src} | {color_edition=}")
        return

    logger.info("Compiling LaTeX...")
    success = compile_latex(dir_src / "Master.tex")

    # Clean up all .tex files, if tectonic was successful and not debugging.
    if not success:
        logger.critical(f"Failed to build {dir_src}.")
        sys.exit(1)

    # Rename the Master.pdf to Volume x.pdf or Volume x - Dark.pdf if not light theme.
    # Or Master - Colored Edition.pdf if color edition.

    # Get the volume string.
    # Remove the leading "% " from the volume string.
    volume_str = get_latex_master_section(binder.master.content, "metadata-volume-string")[2:]
    volume_num_str = get_latex_master_section(binder.master.content, "volume")
    volume_num = re.search(r"\d+([.,]\d+)?", volume_num_str).group(0)
    file_name = f"{volume_str} {volume_num}"
    logger.debug(f"Volume string: {file_name}")

    name_suffix = ""
    if output_dir_name is None:
        raise ValueError("output_dir_name cannot be None, function should have exited earlier.")
    (dir_src / output_dir_name).mkdir(exist_ok=True)
    if not light_theme:
        name_suffix += " - Dark"
    if color_edition:
        name_suffix += " - Colored Edition"
    shutil.move(
        dir_src / "Master.pdf",
        dir_src / output_dir_name / f"{file_name}{name_suffix}.pdf",
    )

    if not debug:
        for file in dir_src.glob("*.tex"):
            file.unlink()

    logger.info(f"Built pdf for {dir_src}. Done.")


def generate_all_chapter_title_cards(
    base_dir: Path,
    chapter_titles: dict[str, str],
    background_color: str | None,
    generate_cards: bool = True,
):
    """
    Generate all the chapter covers.

    :param base_dir: The base directory.
    :param chapter_titles: The chapter filename: title dictionary.
    :param background_color: [Optional] The background color of the end card.
    :param generate_cards: [Optional] Whether to generate the title cards.
    """

    if not generate_cards:
        logger.debug("Already generated chapter title cards. Skipping.")
        return

    USE_MULTIPROCESSING = False

    if USE_MULTIPROCESSING:
        # Run each generator in parallel, because they each take a second running inkscape.
        with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
            for filename, title in chapter_titles.items():
                executor.submit(
                    generate_chapter_title_card,
                    base_dir,
                    filename,
                    title,
                    background_color,
                )
    else:
        for filename, title in chapter_titles.items():
            generate_chapter_title_card(base_dir, filename, title, background_color)


def generate_chapter_title_card(
    base_dir: Path, filename: str, title: str, background_color: str | None
):
    """
    Generate a chapter covers as png files.
    Place the file in the base directory / title_cards
    Titles have the forms:
    "Chapter 1: The Beginning"
    "Prologue: The Beginning"
    "Epilogue: The End"
    "Interlude( 1)?: The Middle"
    Anything not recognized here will be ignored.
    Chapter titles may include a pipe character, which will indicate a line break.

    :param base_dir: The base directory.
    :param filename: The filename.
    :param title: The title.
    :param background_color: [Optional] The background color of the end card.
    :return:
    """

    # Get chapter type and number.
    title_match = re.match(r"^(Chapter|Prologue|Epilogue|Interlude|Story)( (\d+))?: (.*)", title)
    if title_match is None:
        # Suppress warnings for Afterword and Manga.
        if title not in ["Afterword", "Manga"]:
            logger.warning(f"Could not generate a card for chapter title: {title}")
        return

    # Get the chapter type.
    chapter_type: str = title_match.group(1)

    # Get the chapter number. May be None.
    chapter_number: str = title_match.group(3)

    # Get the chapter title.
    chapter_title: str = title_match.group(4).replace("|", "\n")

    # Make sure the prospective filename isn't taken and the directory exists.
    title_card_dir = base_dir / "title_cards"
    title_card_dir.mkdir(exist_ok=True)
    title_card_path = title_card_dir / f"{hp.chapter_name_to_ref(filename)}.png"
    if title_card_path.is_file():
        logger.debug(f"Regenerating title card for {filename}")
        title_card_path.unlink()

    if chapter_type == "Chapter":
        generator.generate_chapter_cover(
            chapter_title, int(chapter_number), title_card_path, background_color
        )
    elif chapter_type == "Prologue":
        generator.generate_prologue_cover(chapter_title, title_card_path, background_color)
    elif chapter_type == "Epilogue":
        generator.generate_epilogue_cover(chapter_title, title_card_path, background_color)
    elif chapter_type == "Interlude":
        generator.generate_interlude_cover(chapter_title, title_card_path, background_color)
    elif chapter_type == "Story":
        generator.generate_story_cover(
            chapter_title, int(chapter_number), title_card_path, background_color
        )
    else:
        logger.error(f"Unknown chapter type: {chapter_type}")


def insert_scene_break_images(base_dir: Path):
    """
    Copy the scene break images into base_dir / figures.
    This way latex can find them.

    :param base_dir: The base directory.
    """
    figures_dir = base_dir / "figures"
    with resources.files(slime_builder.templates) as templates_dir:
        soft_break = str(templates_dir / "softscenebreak.png")
        hard_break = str(templates_dir / "hardscenebreak.png")

    figures_dir.mkdir(exist_ok=True)
    shutil.copy(soft_break, figures_dir / "softscenebreak.png")
    shutil.copy(hard_break, figures_dir / "hardscenebreak.png")


def find_chapter_titles(binder: st.FileBinder) -> dict[str, str]:
    """
    Find the chapter titles.

    :param binder: The file binder.

    :return: A list of chapter file names and titles.
    """
    return {file.path.name: find_chapter_title(file) for file in binder.sections}


def find_chapter_title(file: st.File) -> str:
    """
    Find the chapter title.

    :param file: The file.

    :return: The chapter title.
    """
    # Ignore for files with the name manga.
    if file.path.name == "Manga":
        return "Manga"

    for line in file.content.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    else:
        raise ValueError(f"Could not find chapter title in {file.path.name}")


def markout_to_latex_master(
    markout: str,
    chapter_titles: dict[str, str],
    base_dir: Path,
    image_dir: str,
    fallback_image_dir: str,
    light_theme: bool,
    color_edition: bool,
    text_font_path: str | None,
    volume_color: str | None,
    keep_color_edition_text: bool = False,
) -> str:
    """
    The master will work off of a template, inserting parts of the markout as they fit.

    :param markout: The raw document.
    :param chapter_titles: The chapter titles by file name.
    :param base_dir: The base directory.
    :param image_dir: The image directory.
    :param fallback_image_dir: The fallback image directory.
    :param color_edition: Whether to use the color edition.
    :param light_theme: Whether to use the light theme.
    :param text_font_path: The path used for the main font, required to align labeled lists.
        If None, the labels will only crudely align.
    :param volume_color: The color of the volume, if any. Used for links and headings.
    :param keep_color_edition_text: When True, the color edition text will be kept, even when
        the color edition is not being used.

    :return: LaTeX source.
    """
    # Use fallback image dir

    class Stage(Enum):
        COVER = auto()
        INSERT = auto()
        TITLE = auto()
        CREDITS = auto()
        INCLUDES = auto()

    latex = load_master_tex()

    # Insert the theme.
    if light_theme:
        latex = latex.replace("@STYLESHEET", load_light_theme(volume_color))
    else:
        latex = latex.replace("@STYLESHEET", load_dark_theme(volume_color))

    # Expand cover macro for a redundant image name.
    # ![cover] -> ![cover](cover)
    markout = re.sub(r"!\[cover]$", "![cover](cover)", markout, flags=re.MULTILINE)

    # Insert markout as is into @INSERT until ?[title] is found.
    stage = Stage.COVER
    buffer = ""

    for line in markout.splitlines(keepends=True):
        if stage == Stage.COVER:
            # Look for ![cover](img path) and convert it to a full page image in the @COVER section.
            if cover_match := re.match(r"!\[cover]\((.*)\)", line):
                latex = latex.replace(
                    "@COVER",
                    f"\\fullpageimage{{"
                    f"{hp.smart_path(base_dir, image_dir, fallback_image_dir, cover_match.group(1))}}}",
                )
                stage = Stage.INSERT
            # Ignore everything until this was found.
            continue
        elif stage == Stage.INSERT:
            if title_match := re.search(r"\?\[title]\((.*)\)", line):
                stage = Stage.TITLE
                # Flush buffer to @INSERT
                latex = latex.replace("@INSERT", buffer).replace("@TITLE", title_match.group(1))
                buffer = ""
                continue  # Don't add line to buffer.
        elif stage == Stage.TITLE:
            if volume_match := re.search(r"\?\[volume]\((.*)\)(\{(.*)})?", line):
                col_str = "Colored Edition" if color_edition else ""
                volume_string = volume_match.group(3) if volume_match.group(3) else "Volume"
                stage = Stage.CREDITS
                latex = (
                    latex.replace("@VOLUME", volume_match.group(1))
                    .replace("@COLOREDITION", col_str)
                    .replace("@METADATA-VOLUME-STRING", volume_string)
                )
                continue
        elif stage == Stage.CREDITS:
            # Just add everything as is until we hit the ?[edition] tag.
            if edition_match := re.search(r"\?\[edition]\((.*)\)", line):
                stage = Stage.INCLUDES
                # Flush the buffer to @CREDITS
                latex = latex.replace("@CREDITS", buffer)
                edition_str = edition_match.group(1)
                # Append ": <date>" to the edition string, as M YYYY.
                edition_str += f": {datetime.date.today().strftime('%B %Y')}"
                latex = latex.replace("@EDITION", edition_str)
                buffer = ""
                continue
        elif stage == Stage.INCLUDES:
            # Just add everything except the ?[arc] tag.
            if arc_match := re.search(r"\?\[arc]\((.*)\)", line):
                latex = latex.replace("@ARC", arc_match.group(1))
                continue

        buffer += line

    # Flush the remaining buffer to @INCLUDES
    latex = latex.replace("@INCLUDES", buffer)

    # Generate the table of contents using the include statements.
    toc_includes = (match.group(1) for match in re.finditer(r"!\[include]\((.*)\)", latex))
    try:
        toc_includes = (
            f"\\contentsref{{{hp.chapter_name_to_ref(include)}}}"
            f"{{{plain_chapter_title(chapter_titles[include])}}}"
            for include in toc_includes
        )
    except KeyError as e:
        logger.critical(f"Missing chapter title for {e}")
        sys.exit(1)
    latex = latex.replace("@CONTENTS", "\n\n".join(toc_includes))

    # Resolve master-specific macros.
    latex = latex.replace("![break]", r"\creditspace")
    latex = latex.replace("![disclaimer]", r"\disclaimer")
    latex = re.sub(r"!\[include]\((.*)\)", r"\n\\pagebreak\n\\input{\1.tex}", latex)
    latex = re.sub(
        r"\?\[color edition only]\((.*)\)",
        lambda match: match.group(1) if color_edition or keep_color_edition_text else "",
        latex,
    )

    # Perform all other standard conversions.
    latex = markout_to_latex(
        latex, base_dir, image_dir, fallback_image_dir, text_font_path, exclude_special=True
    )

    return latex


def markout_to_latex(
    markout: str,
    base_dir: Path,
    image_dir: str,
    fallback_image_dir: str,
    text_font_path: str | None,
    exclude_special: bool = False,
) -> str:
    """
    Convert Markout to LaTeX.

    :param markout: The Markout text.
    :param base_dir: The base directory.
    :param image_dir: The image directory.
    :param fallback_image_dir: The fallback image directory.
    :param text_font_path: The path to the text font. If None, the labels will only crudely align.
    :param exclude_special: Whether to exclude underscores and percent signs from the conversion.
        They may not be messed with in the Master.
    """
    # Strip whitespace from front and back of lines.
    markout = "\n".join(line.strip() for line in markout.splitlines())

    # Replace all underscores (not preceded by a \) with \_ if not excluded. Otherwise LaTeX expects math-mode.
    if not exclude_special:
        markout = re.sub(r"(?<!\\)_", r"\_", markout)
        markout = re.sub(r"(?<!\\)%", r"\%", markout)

    # Convert image tags.
    # From ![full page image](image27.png){optional alt text} to \fullpageimage[alt text]{image_dir/image27.png}
    # From ![exact fit image](image27.png) to \exactfitimage{image_dir/image27.png}
    markout = re.sub(
        r"!\[full page image]\((.*?)\)({(.*?)})?",
        lambda match: f"\\fullpageimage[{match.group(3)}]"
        f"{{{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}"
        if match.group(3)
        else f"\\fullpageimage{{{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}",
        markout,
    )
    markout = re.sub(
        r"!\[exact fit image]\((.*?)\)({(.*?)})?",
        lambda match: f"\\exactfitimage[{match.group(3)}]"
        f"{{{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}"
        if match.group(3)
        else f"\\exactfitimage{{{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}",
        markout,
    )

    # Convert manga header.
    # Allow omitting the image name, if it is "manga".
    # From ![manga](image27.png){optional alt text} to \mangaheader[alt text]{image_dir/image27.png}
    # From ![manga] to \mangaheader{image_dir/manga.png}
    markout = re.sub(r"!\[manga]$", r"![manga](manga)", markout, flags=re.MULTILINE)

    markout = re.sub(
        r"!\[manga]\((.*?)\)({(.*?)})?",
        lambda match: f"\\mangaheader[{match.group(3)}]"
        f"{{{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}"
        if match.group(3)
        else f"\\mangaheader{{"
        f"{hp.smart_path(base_dir, image_dir, fallback_image_dir, match.group(1))}}}",
        markout,
    )

    # Handle italic and bold and strikethrough markup.
    # From **bold** to \textbf{bold}
    # From *italic* to \textit{italic}
    # From ~~strikethrough~~ to \sout{strikethrough}
    markout = re.sub(r"\*\*(.*?)\*\*", r"\\textbf{\1}", markout)
    markout = re.sub(r"\*(.*?)\*", r"\\emph{\1}", markout)
    markout = re.sub(r"~~(.*?)~~", r"\\sout{\1}", markout)

    if not exclude_special:
        markout = re.sub(r"(?<!\\)~", r"\~", markout)

    # Handle quotes.
    # From "quote" to ``quote''
    markout = re.sub("^'", "‘", markout, flags=re.MULTILINE)
    markout = re.sub("([^ —-])'", r"\1’", markout)
    markout = re.sub("'", "‘", markout)
    markout = re.sub("{['’]", "{‘", markout)
    markout = re.sub(r"\[['’]", "[‘", markout)
    markout = re.sub("‘", "`", markout)
    markout = re.sub("’", "'", markout)

    markout = re.sub('^"', "“", markout, flags=re.MULTILINE)
    markout = re.sub('([^ —-])"', r"\1”", markout)
    markout = re.sub('"', "“", markout)
    markout = re.sub('{["”]', "{“", markout)
    markout = re.sub(r'\[["”]', "[“", markout)
    markout = re.sub("“", "``", markout)
    markout = re.sub("”", "''", markout)

    markout = re.sub("``$", "''", markout, flags=re.MULTILINE)
    markout = re.sub("`$", "'", markout, flags=re.MULTILINE)

    markout = re.sub(r"'' ``(\w)", r"`` ``\1", markout, flags=re.MULTILINE)
    markout = re.sub(r"'' ``", r"'' ''", markout, flags=re.MULTILINE)
    markout = re.sub(r"'' '' ``", r"'' '' ''", markout)

    markout = re.sub(r"<<", "«", markout)
    markout = re.sub(r">>", "»", markout)
    markout = re.sub(r"<", "‹", markout)
    # Only substitute > if it is not at the beginning of a line.
    # This is to protext the > used to denote extra paragraphs in a list.
    markout = re.sub(r"(?<!^)>", "›", markout, flags=re.MULTILINE)

    markout = re.sub(r"&", r"\&", markout)

    markout = re.sub(r"\$", r"\\$", markout)
    markout = re.sub(r"🡪", r" -> ", markout)

    # Also automatically convert ordinal numbers to use superscript.
    markout = re.sub(r"\^(\w+)\^", r"\\textsuperscript{\1}", markout)
    markout = re.sub(r"(?<=\d)(st|nd|rd|th)\b", r"\\textsuperscript{\1}", markout)

    markout = re.sub(r"—", "---", markout)
    markout = re.sub(r"\.\.\.|…", r"\\ldots{}", markout)

    # Fix backwards quote-to-punctuation. ''. -> .'' (or similar).
    markout = re.sub(r"(''|')([,.])", r"\2\1", markout)

    markout = re.sub(r"!\[break]", r"\\textbreak", markout)
    # Try to find the following paragraph and add a \noindent after a scene break.
    markout = re.sub(
        r"!\[hard scene break]((\s+)(\S))", r"\\hardscenebreak\2\\noindent \3", markout
    )
    markout = re.sub(
        r"!\[soft scene break]((\s+)(\S))", r"\\softscenebreak\2\\noindent \3", markout
    )
    markout = re.sub(r"!\[hard scene break]", r"\\hardscenebreak", markout)
    markout = re.sub(r"!\[soft scene break]", r"\\softscenebreak", markout)

    markout = re.sub(r"\^\[(.*?)]", r"\\footnote{\1}", markout)

    # Find ordered lists in markdown and convert to LaTeX using itemize.
    # Example:
    # 1. Item 1
    # 2. Item 2
    # Becomes:
    # \begin{itemize}
    # \item Item 1
    # \item Item 2
    # \end{itemize}
    # Also allow added paragraphs: (blank lines between paragraphs require the > as well)
    # 1. Item 1
    #
    # > Paragraph 1
    # >
    # > Paragraph 2
    #
    # 2. Item 2
    # First, make \item tags.
    markout = re.sub(r"^- +(.*)$", r"\\item \1", markout, flags=re.MULTILINE)
    # Surround one or more item tags with the itemize scope.
    markout = re.sub(
        r"((\n\\item .*?\n(> ?.*?\n)*)+)",
        partial(handle_labeled_lists, text_font_path=text_font_path),
        markout,
        flags=re.MULTILINE,
    )

    # Handle chapter headers.
    markout = re.sub(
        r"^# (Chapter \d+|Prologue|Epilogue|Interlude( \d)?|Story \d+): (.+)$\n+(.)",
        lambda match: f"\\chapterheader{{{hp.chapter_name_to_ref(match.group(1))}}}"
        f"{{{match.group(1)}}}{{{match.group(3).replace('|', ' ')}}}"
        f"\n\n\\noindent {match.group(4)}",
        markout,
        flags=re.MULTILINE,
    )

    # Handle Afterword header.
    markout = re.sub(
        r"# Afterword$\n+(.)",
        r"\\afterwordheader\n\n\\noindent \1",
        markout,
        flags=re.MULTILINE,
    )

    # Handle links.
    markout = re.sub(r"(?<![!?^])\[(.*?)]\((.*?)\)", r"\\href{\2}{\\uline{\1}}", markout)

    return markout


def handle_labeled_lists(regex_match: re.Match, text_font_path: str | None) -> str:
    r"""
    If there are any ?[label] tags,
    replace \item ?[label](text)
    with \item[text]
    and calculate the length of each string using black magic.
    Then insert the longest length into the [leftmargin] command for
    the itemize.

    :param regex_match: match of the list items.
    :param text_font_path: path to the text font. Used to calculate the length of the labels.
        If None, the labels will be crudely aligned.
    :return: the formatted replacement.
    """
    # Remove > if it is the first letter in a line from the regex match group 1.
    items = re.sub(r"^\s*> *", "", regex_match.group(1), flags=re.MULTILINE)
    # Replace any <br> tags with paragraph breaks.
    items = re.sub(r"\\\\ *", r"\\\\%HTML-list-break\n", items)

    # Find labels.
    labels = re.findall(r"\\item +\?\[label]\((.*?)\)", regex_match.group(0))

    if not labels:
        return f"\\begin{{itemize}}[leftmargin=1cm, listparindent=0.75cm]{items}\\end{{itemize}}"

    # Find the longest label.
    label_lengths: dict[str, float]
    if text_font_path:
        label_lengths = {
            label: hp.arcane_formula_for_text_width(label, text_font_path) for label in labels
        }
    else:
        # Simply go by char count.
        label_lengths = {label: len(label) for label in labels}

    max_length_label = max(label_lengths, key=label_lengths.get)

    # Reformat the label tags.
    labels_and_items = re.sub(r"^\s*> *", "", regex_match.group(0), flags=re.MULTILINE)
    # Replace any <br> tags with paragraph breaks.
    labels_and_items = re.sub(r"\\\\ *", r"\\\\%HTML-list-break\n", labels_and_items)
    new_items = re.sub(
        r"\\item +\?\[label]\((.*?)\)",
        lambda match: f"\\item[{match.group(1)}]",
        labels_and_items,
    )

    # Return the formatted replacement. Add a labelsep and add it from the margin as well.
    return (
        "\n\\begin{itemize}[labelsep=0.3cm, listparindent=0.75cm, leftmargin="
        + f"\widthof{{{max_length_label}}}+0.5cm"
        + "] % HTML-HINT: LABELED\n"
        + new_items
        + "\n\\end{itemize}\n"
    )


def plain_chapter_title(name: str) -> str:
    """
    Strip out the pipes that are for chapter cover generation.
    """
    return name.replace("|", " ")


def load_master_tex():
    """
    Load the tex file using importlib.
    """
    return load_file("master.tex")


def load_dark_theme(color: str | None) -> str:
    """
    Load the dark theme.

    :param color: the color to use for the theme. It is somewhat lightened and desaturated.
    """
    return load_file("dark_theme.tex").replace(
        "#VOLUME_COLOR#", hp.adjust_color(color, light=False)
    )


def load_light_theme(color: str | None) -> str:
    """
    Load the light theme.
    :param color: the color to use for the theme. It is somewhat lightened and desaturated.
    """
    return load_file("light_theme.tex").replace(
        "#VOLUME_COLOR#", hp.adjust_color(color, light=True)
    )


def load_file(filename: str):
    """
    Load the sheet file using importlib.
    """
    with resources.open_text(templates, filename) as f:
        return f.read()


def compile_latex(latex_file: Path) -> bool:
    """
    Compile the LaTeX file using tectonic.

    :param latex_file: the path to the LaTeX file.
    :return: True if the conversion was successful, False otherwise.
    """

    try:
        subprocess.check_output(
            ["tectonic", str(latex_file)],
            stderr=subprocess.STDOUT,
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"Error compiling LaTeX: {latex_file}")
        logger.error(e.output.decode("utf-8"))
        return False
    except Exception as e:
        logger.error(f"Failed to run tectonic: {latex_file}")
        logger.exception(e)
        return False

    logger.info(f"Done compiling LaTeX: {latex_file}")
    return True
