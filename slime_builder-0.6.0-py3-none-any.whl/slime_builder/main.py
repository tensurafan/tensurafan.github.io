"""Slime Builder

Usage:
    slime-builder build pdf [<source_dir>] [--all] [--dark-theme] [--color-edition]
                  [--latex] [--internal-font=<font_path>] [--debug]
    slime-builder build epub [<source_dir>] [--all | --color-edition] [--skip-other-formats] [--debug]
    slime-builder build reader [<source_dir>] [--terms=<terms_file>] [--debug]
    slime-builder build all [--only=<source_dir> | --from=<source_dir>]
                  [--only-pdf | --only-epub | --only-reader]
                  [--terms=<terms_file>] [--internal-font=<font_path>] [--debug]
    slime-builder check [<source>] [-e | --errors-only] [--debug]
    slime-builder extract-terms <spreadsheet> [--output-path=<terms_file>] [--debug]
    slime-builder unpack <zip_file> [--debug]
    slime-builder pack [<source_dir>] [--debug]
    slime-builder convert-legacy <docx_file> [--debug]
    slime-builder config [--debug]
    slime-builder clean [<source_dir>] [--all] [--deep] [--debug]
    slime-builder (-h | --help | --version)
    
Subcommands:
    build                 Build one or more formats from the source directory.
        pdf               Build a PDF from the source directory.
        epub              Build an EPUB file from the source directory.
        reader            Build html for Slime Reader from the source directory.
        all               Build all formats from the source directory, or only the specified directory/format.
                          You can set a base directory to search for source directories from, by default the current
                          working directory is used.
    check                 Check the source directory or single file for errors. Static analysis only.
    extract-terms         Extract terms from a spreadsheet and output them as a JSON file.
    unpack                Unpack a zip file of a project. The contents are placed in a subdirectory of
                          the zip file's directory. This is meant for the docx files stored in a google drive.
                          The files within are cleaned up and automatically converted to plain text.
    pack                  Pack a markout project directory into a zip file.
    convert-legacy        Convert a legacy docx file to a markout project directory.
    config                Show the config file path and contents.
    clean                 Clean a source directory or all subdirectories, if they are markout projects.
                          This removes all temporary tex files.

Options:
    <source_dir>                  The directory containing the source files. By default, the current working directory.
    <source>                      The markout source directory or file to check.
    <zip_file>                    The zip file to unpack.
    <docx_file>                   The legacy docx file to convert.
    <spreadsheet>                 The spreadsheet to extract terms from. Most formats supported, including .ods, .csv, .xls, .xlsx. etc.
    --all                         Build all formats, not just the one specified.
    --only=<source_dir>           Only build the specified source directory.
    --from=<source_dir>           Only build source directories from the specified directory.
    -P --only-pdf                 Only build the PDF format.
    -E --only-epub                Only build the EPUB format.
    -R --only-reader              Only build the Slime Reader format.
    -d --dark-theme               Use the dark theme for the PDF.
    -c --color-edition            Use the color edition for the PDF/EPUB.
    -s --skip-other-formats       Skip converting to other formats (currently mobi and azw3) when building the EPUB.
    --terms=<terms_file>          The terms file to use for the Slime Reader. This is cached in the config.
    --internal-font=<font_path>   The path to the font file to use for aligning labels in the PDF. This is cached in the config.
    --output-path=<terms_file>    The path to the output terms file. By default, the terms file is placed in the source directory.
    --deep                        Clean up the generated images, pdfs and epubs as well.
    -l --latex                    Output the latex source files instead of compiling them.
    -e --errors-only              Only show errors, not warnings.
    -h --help                     Show this screen.
    --debug                       Do not clean up the output directory and show debugging information.
    --version                     Show version.
"""
# TODO
# testing
# Try stringIO to optimize speed.
# Check for files not mentioned in master

import itertools
import os
import sys
from pathlib import Path
import shutil
from concurrent.futures import ThreadPoolExecutor

import docopt
from docopt import docopt
from logzero import logger, loglevel, DEBUG, INFO

from slime_builder.html_builder import builder as html_builder
import slime_builder.helpers as hp
from slime_builder import __version__, __program__
import slime_builder.config as cfg
from slime_builder import (
    latex_builder,
    doczip_unpacker,
    markout_packer,
    legacy_importer,
    term_extractor,
    markout_check,
)


def main(argv=None):
    """
    The main entry point for the CLI.
    """
    if argv is None:
        argv = sys.argv[1:]

    args = docopt(__doc__, argv=argv, version=f"{__program__} {__version__}")

    # Loglevel is info by default.
    if args.debug:
        loglevel(DEBUG)
    else:
        loglevel(INFO)

    logger.debug(args)

    args.source_dir = source_dir_guard(args["<source_dir>"])

    conf = load_and_set_config(args)

    # Jump to the appropriate subcommand.
    if args.build:
        # Create a single-use bool to limit the number of times title cards get generated to once per volume.
        # noinspection PyTypeChecker
        once_bool: bool = hp.OneTimeBool()

        if args.pdf:
            build_pdf(
                source_dir=args.source_dir,
                conf=conf,
                use_dark_theme=args.dark_theme,
                use_color_edition=args.color_edition,
                latex_only=args.latex,
                compile_all=args["--all"],
                generate_cards=once_bool,
                debug=args.debug,
            )
        elif args.epub:
            build_epub(
                source_dir=args.source_dir,
                conf=conf,
                use_color_edition=args.color_edition,
                compile_all=args["--all"],
                skip_other_formats=args.skip_other_formats,
                generate_cards=once_bool,
                debug=args.debug,
            )
        elif args.reader:
            build_reader(
                source_dir=args.source_dir,
                conf=conf,
                generate_cards=once_bool,
                debug=args.debug,
            )
        # Because build all can do multiple volumes, it handles its own single-use bool.
        elif args.all:
            build_all(
                only_dir=args["--only"],
                from_dir=args["--from"],
                conf=conf,
                only_pdf=args.only_pdf,
                only_epub=args.only_epub,
                only_reader=args.only_reader,
                debug=args.debug,
            )

    elif args.unpack:
        doczip_unpacker.unpack_zip(Path(args.zip_file))
    elif args.pack:
        markout_packer.pack(Path(args.source_dir))
    elif args.convert_legacy:
        conf = cfg.load_config()
        legacy_importer.import_legacy_format(Path(args.docx_file), conf.IMG_DIR)
    elif args.clean:
        clean(Path(args.source_dir), args["--all"], args.deep)
    elif args.check:
        check(args.source, args.errors_only, args.debug)
    elif args.extract_terms:
        extract_spreadsheet_terms(args.spreadsheet, args.output_path)
    elif args.config:
        show_config()
    else:
        logger.error("No subcommand specified.")


def source_dir_guard(source_dir: str | None) -> Path:
    """
    Ensure the source directory exists.
    """

    if source_dir is None:
        source_dir = Path.cwd()
    else:
        try:
            source_dir = Path(source_dir)
        except TypeError:
            raise ValueError(f"Invalid source directory: {source_dir}")

    if not source_dir.is_dir():
        raise ValueError(f'Source directory "{source_dir}" does not exist.')

    return source_dir.resolve()


def build_pdf(
    source_dir: Path,
    conf: cfg.Config,
    use_dark_theme: bool,
    use_color_edition: bool,
    latex_only: bool,
    compile_all: bool,
    generate_cards: bool,
    debug: bool,
) -> None:
    """
    Build a PDF from the source directory.

    If the --all flag is set, build all different combinations of themes and color/monochrome editions.
    Otherwise build the selected theme and color/monochrome edition.
    By default, build the monochrome edition of the light theme.

    If the --latex flag is set, only generate the LaTeX source files. These are normally cleaned up.
    This is used for debugging. (And internally by the epub and reader subcommands.)

    The --internal-font option is used to specify a font file path to use for calculating list label offsets.
    If none is specified, first check if there is an environment variable INTERNAL_LABEL_FONT_PATH and use that.
    If that fails, a crude approximation is used.

    :param source_dir: The source directory.
    :param conf: The configuration object holding various constants.
    :param use_dark_theme: Whether to use the dark theme.
    :param use_color_edition: Whether to use the color edition.
    :param latex_only: Whether to only generate the LaTeX source files without compiling the pdf.
    :param compile_all: Whether to build all different combinations of themes and color/monochrome editions.
    :param generate_cards: Whether to generate title cards.
    :param debug: Whether to show debugging information.
    """

    text_font_path = conf.internal_label_font_path

    if not compile_all:
        logger.debug(
            f"Building PDF for single theme and edition: {use_dark_theme=}, {use_color_edition=}"
        )
        # Build the selected theme and color/monochrome edition.
        latex_builder.latex_build(
            source_dir,
            output_dir_name=conf.OUT_DIR if not use_color_edition else conf.OUT_DIR_COLORED,
            light_theme=not use_dark_theme,
            color_edition=use_color_edition,
            latex_only=latex_only,
            image_dir=conf.IMG_DIR,
            colored_image_dir=conf.COLORED_IMG_DIR,
            endcard_file_name=conf.ENDCARD_FILE_NAME,
            text_font_path=text_font_path,
            generate_cards=generate_cards,
            debug=debug,
        )
    else:
        logger.debug("Building PDF for all themes and editions.")
        # Build all different combinations of light/dark and color/monochrome editions.
        for use_light_theme, use_color_edition in itertools.product([True, False], repeat=2):
            latex_builder.latex_build(
                source_dir,
                output_dir_name=conf.OUT_DIR if not use_color_edition else conf.OUT_DIR_COLORED,
                light_theme=use_light_theme,
                color_edition=use_color_edition,
                latex_only=latex_only,
                image_dir=conf.IMG_DIR,
                colored_image_dir=conf.COLORED_IMG_DIR,
                endcard_file_name=conf.ENDCARD_FILE_NAME,
                text_font_path=text_font_path,
                generate_cards=generate_cards,
                debug=debug,
                suppress_missing_color=True,
            )


def build_epub(
    source_dir: Path,
    conf: cfg.Config,
    use_color_edition: bool = False,
    compile_all: bool = False,
    skip_other_formats: bool = False,
    generate_cards: bool = True,
    suppress_missing_color: bool = False,
    debug: bool = False,
) -> None:
    """
    Build an EPUB prototype from the source directory.

    If the --all flag is set, build both color/monochrome editions.
    Otherwise build the color edition if the --color-edition flag is set.
    By default, build the monochrome edition.

    :param source_dir: The source directory.
    :param conf: The configuration object holding various constants.
    :param use_color_edition: [Optional] Whether to use the color edition.
    :param compile_all: [Optional] Whether to build both color/monochrome editions.
    :param skip_other_formats: Whether to skip converting to other ebook formats (mobi, azw3).
    :param generate_cards: Whether to generate title cards.
    :param suppress_missing_color: Whether to silently fail color editions, if they can't be made.
    :param debug: Whether to show debugging information.
    """
    # When compiling all, split this into two separate calls.
    # One for the color edition and one for the monochrome edition.
    if compile_all:
        build_epub(
            source_dir,
            conf,
            use_color_edition=False,
            compile_all=False,
            skip_other_formats=skip_other_formats,
            generate_cards=generate_cards,
            debug=debug,
        )
        build_epub(
            source_dir,
            conf,
            use_color_edition=True,
            compile_all=False,
            skip_other_formats=skip_other_formats,
            generate_cards=generate_cards,
            suppress_missing_color=True,
            debug=debug,
        )
        return

    # Build the latex source files.
    # These get cleaned up in the end if not in debug mode.
    latex_builder.latex_build(
        source_dir,
        output_dir_name=conf.OUT_DIR if not use_color_edition else conf.OUT_DIR_COLORED,
        light_theme=False,
        color_edition=use_color_edition,
        latex_only=True,
        text_font_path=None,
        image_dir=conf.IMG_DIR,
        colored_image_dir=conf.COLORED_IMG_DIR,
        endcard_file_name=conf.ENDCARD_FILE_NAME,
        generate_cards=generate_cards,
        suppress_missing_color=suppress_missing_color,
        debug=debug,
    )
    binder = html_builder.latex_to_html_primitive(
        source_dir,
        figure_dir=conf.FIGURE_DIR,
        title_card_dir=conf.TITLE_CARD_DIR,
        suppress_failed_color=suppress_missing_color,
    )
    if binder is None:
        logger.debug(
            "Skipping epub build, the latex build was skipped due to lacking color images."
        )
        return

    # Build the selected theme and color/monochrome edition.
    html_builder.html_primitive_to_epub(
        source_dir,
        colored_edition=use_color_edition,
        binder=binder,
        output_dir_name=conf.OUT_DIR if not use_color_edition else conf.OUT_DIR_COLORED,
        image_dir=conf.IMG_DIR,
        colored_image_dir=conf.COLORED_IMG_DIR,
        figure_dir=conf.FIGURE_DIR,
        title_card_dir=conf.TITLE_CARD_DIR,
        skip_other_formats=skip_other_formats,
        suppress_missing_color=suppress_missing_color,
    )

    # Clean the latex files.
    if not debug:
        clean(source_dir)


def build_reader(
    source_dir: Path,
    conf: cfg.Config,
    generate_cards: bool,
    debug: bool,
) -> None:
    """
    Build Slime Reader html files from the source directory.

    A terms.json file is required to apply term replacements.

    :param source_dir: The source directory.
    :param conf: The configuration object holding various constants.
    :param generate_cards: Whether to generate title cards.
    :param debug: Whether to show debugging information.
    """

    logger.info(f"Using terms file: {conf.terms_file_path}")
    terms_file = None
    if conf.terms_file_path is not None:
        terms_file = Path(conf.terms_file_path)
        if not terms_file.exists():
            logger.error(f"Terms file {terms_file} does not exist, skipping term replacement.")
            terms_file = None

    # Build the latex source files.
    # These get cleaned up in the end if not in debug mode.
    latex_builder.latex_build(
        source_dir,
        output_dir_name=None,
        light_theme=False,
        color_edition=False,
        latex_only=True,
        image_dir=conf.IMG_DIR,
        colored_image_dir=conf.COLORED_IMG_DIR,
        endcard_file_name=conf.ENDCARD_FILE_NAME,
        text_font_path=None,
        generate_cards=generate_cards,
        debug=debug,
        keep_color_edition_text=True,
    )
    binder = html_builder.latex_to_html_primitive(
        source_dir,
        figure_dir=conf.FIGURE_DIR,
        title_card_dir=conf.TITLE_CARD_DIR,
        debug=debug,
    )

    html_builder.html_primitive_to_slime_reader(
        source_dir,
        terms_file=terms_file,
        binder=binder,
        image_dir=conf.IMG_DIR,
        colored_image_dir=conf.COLORED_IMG_DIR,
        reader_html_dir=conf.READER_HTML_DIR,
        reader_img_dir=conf.READER_IMG_DIR,
    )
    # Clean the latex files.
    if not debug:
        clean(source_dir)


def build_all(
    only_dir: Path | None,
    from_dir: Path | None,
    conf: cfg.Config,
    only_pdf: bool,
    only_epub: bool,
    only_reader: bool,
    debug: bool,
) -> None:
    """
    Build all formats in immediate subdirectories of the current working directory.
    Optionally, only build the specified directory and or format.

    :param only_dir: [Optional] Only build the specified directory.
    :param from_dir: [Optional] Search for directories to build from the specified directory. Otherwise the cwd is used.
    :param conf: The configuration object holding various constants.
    :param only_pdf: Whether to only build the PDF.
    :param only_epub: Whether to only build the EPUB.
    :param only_reader: Whether to only build the Slime Reader files.
    :param debug: Whether to show debugging information.
    """

    def folder_contains_master_file(folder: Path) -> bool:
        return any(folder.glob("Master")) or any(folder.glob("master"))

    if from_dir is not None:
        # Search from here, rather than the current working directory.
        from_dir = Path(from_dir)
        if not from_dir.is_dir():
            logger.critical(f"Directory {from_dir} does not exist.")
            sys.exit(1)
    else:
        from_dir = Path.cwd()

    if only_dir is not None:
        # If a directory was specified, only build that one.
        source_dirs = [Path(only_dir)]
    else:
        print("Searching for source directories...")
        # If the current working directory contains a Master file, build that.
        if folder_contains_master_file(from_dir):
            source_dirs = [from_dir]
        # Otherwise, get all immediate subdirectories of the current working directory that contain a Master file.
        else:
            source_dirs = [
                Path(d).resolve()
                for d in from_dir.iterdir()
                if Path(d).is_dir() and folder_contains_master_file(Path(d))
            ]

        if not source_dirs:
            logger.error(f"No source directories found in {from_dir}.")
            sys.exit(0)

    logger.info(
        f'Building {len(source_dirs)} {hp.f_plural(len(source_dirs), "volume", "volumes")} from "{from_dir}":\n'
        + "\n".join([str(d.name) for d in source_dirs])
    )

    # Helper function to build a single volume.
    def build_all_of(current_source_dir: Path):
        # Make a single-use bool per volume, so that chapter cards don't get generated over and over.
        # noinspection PyTypeChecker
        once_bool: bool = hp.OneTimeBool()

        try:
            # Build the PDF.
            if not only_epub and not only_reader:
                logger.info(f"Building PDFs for {current_source_dir.name}...")
                build_pdf(
                    current_source_dir,
                    conf,
                    use_dark_theme=False,
                    use_color_edition=False,
                    latex_only=False,
                    compile_all=True,
                    generate_cards=once_bool,
                    debug=debug,
                )

            # Build the EPUB.
            if not only_pdf and not only_reader:
                logger.info(f"Building EPUBs for {current_source_dir.name}...")
                build_epub(
                    current_source_dir,
                    conf,
                    compile_all=True,
                    generate_cards=once_bool,
                    debug=debug,
                )

            # Build the Slime Reader files.
            if not only_pdf and not only_epub:
                logger.info(f"Building Slime Reader files for {current_source_dir.name}...")
                build_reader(current_source_dir, conf, generate_cards=once_bool, debug=debug)

        except Exception as e:
            logger.error(f"Error building {current_source_dir.name}.")
            logger.exception(e)

        # Clean up the temporary files.
        if not debug:
            clean(current_source_dir)

    # End helper function.

    thread_num = os.cpu_count() if not debug else 1  # For debug mode, perform these sequentially.
    with ThreadPoolExecutor(max_workers=thread_num) as executor:
        for source_dir in source_dirs:
            executor.submit(build_all_of, source_dir)

    logger.info("Done.")


def clean(directory: Path, walk_subdirs: bool = False, deep: bool = False) -> None:
    """
    Clean up the LaTeX source files.

    :param directory: The directory to clean.
    :param walk_subdirs: If True, attempt to clean all immediate subdirectories.
    :param deep: If True, also delete the generated images, pdf and epub files.
    """
    conf = cfg.load_config()

    logger.debug(f"Cleaning {directory} and {'sub' if walk_subdirs else 'no sub'}directories.")

    def is_markout_dir(path: Path) -> bool:
        # It needs to be a directory containing a file called Master
        return path.is_dir() and (path / "Master").is_file()

    def clean_dir(path: Path) -> None:
        for file in path.glob("*.tex"):
            logger.debug(f"deleting: {file.name}")
            file.unlink()

        if not deep:
            return
        # Delete the title cards, figures, pdf and epub folder.
        folders_to_delete = (
            path / conf.TITLE_CARD_DIR,
            path / conf.FIGURE_DIR,
            path / conf.OUT_DIR,
            path / conf.OUT_DIR_COLORED,
        )
        for folder in folders_to_delete:
            if folder.is_dir():
                logger.debug(f"deleting: {folder.name}")
                shutil.rmtree(folder)

    if not walk_subdirs:
        if not is_markout_dir(directory):
            logger.error(
                f"Source directory {directory} is not a Markout directory: no Master file."
            )
            return
        clean_dir(directory)

    else:
        # Clean up every direct subdirectory that contains a Master file.
        for sub_path in directory.iterdir():
            if is_markout_dir(sub_path):
                clean_dir(sub_path)


def show_config():
    """
    Show the config save location and the current config.
    """
    conf = cfg.load_config()
    print(f"Configuration file location: {cfg.get_config_path()}")
    print("Current configuration:\n")
    print(conf)
    # Trigger the config to be saved, so that the user may be able to find it.
    cfg.save_config(conf)


def check(source: str | None, errors_only: bool, debug: bool):
    """
    Check a directory or source file for any issues.

    :param source: Directory or file to check.
    :param errors_only: If True, suppress warnings.
    :param debug: If True, show debugging information.
    """
    conf = cfg.load_config()

    if source is None:
        source = Path.cwd()
    else:
        try:
            source = Path(source)
        except TypeError:
            logger.error(f"Source {source} is not a valid path.")
            sys.exit(1)

    markout_check.check_project(source, errors_only, image_dir=conf.IMG_DIR)


def extract_spreadsheet_terms(spreadsheet: str, output_path: str | None):
    """
    Extract terms from the specified spreadsheet and write them to the specified output path.
    These are used by Slime Reader.

    :param spreadsheet: Path to the spreadsheet.
    :param output_path: Path to write the terms to.
    """
    # Ensure the spreadsheet exists.
    try:
        spreadsheet = Path(spreadsheet)
        if not spreadsheet.is_file():
            raise FileNotFoundError
    except (FileNotFoundError, OSError) as e:
        logger.error(f"Spreadsheet {spreadsheet} does not exist.")
        logger.exception(e)
        sys.exit(1)

    # Ensure the output path is valid.
    # It may either be an existing directory or a file.
    # By default, use the spreadsheet's directory if the file isn't absolute.
    if output_path is None:
        output_path = spreadsheet.parent
    else:
        output_path = Path(output_path)
        if output_path.is_dir():
            output_path /= "terms.json"
        elif not output_path.is_absolute():
            output_path = spreadsheet.parent / output_path

    # Ensure the output path's parent directory exists.
    output_path.parent.mkdir(parents=True, exist_ok=True)

    term_extractor.extract_terms(spreadsheet, output_path)


def load_and_set_config(args) -> cfg.Config:
    """
    Load the config file and, if variables are give, set them and overwrite the
    config file.

    :param args: The docopt args object.
    :return: A valid config object.
    """

    conf = cfg.load_config()
    modified = False

    # Try to load the main text label font and terms file from the config, if not specified.
    # Save it in the config so it can be used later.
    logger.debug(f"Font path in args: {args.internal_font}")
    if args.internal_font is not None:
        conf.internal_label_font_path = args.internal_font
        modified = True

    logger.debug(f"Terms file in args: {args.terms}")
    if args.terms is not None:
        conf.terms_file_path = args.terms
        modified = True

    # Check that the paths are valid.
    if (
        conf.internal_label_font_path is not None
        and not Path(conf.internal_label_font_path).is_file()
    ):
        logger.error(
            f"Font file {conf.internal_label_font_path} does not exist. Resetting to None."
        )
        conf.internal_label_font_path = None
        modified = True

    if conf.terms_file_path is not None and not Path(conf.terms_file_path).is_file():
        logger.error(f"Terms file {conf.terms_file_path} does not exist. Resetting to None.")
        conf.terms_file_path = None
        modified = True

    if modified:
        cfg.save_config(conf)

    return conf


if __name__ == "__main__":
    main()
