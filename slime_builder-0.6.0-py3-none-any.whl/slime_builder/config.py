import json
from xdg import XDG_CONFIG_HOME
from pathlib import Path
from dataclasses import dataclass, asdict
from logzero import logger


@dataclass
class Config:
    # These need to be configured manually, if at all.
    IMG_DIR: str = "illustrations"
    COLORED_IMG_DIR: str = "colored_illustrations"
    READER_HTML_DIR: str = "../../"
    READER_IMG_DIR: str = "ln/sources/{volume_str} {volume_number}/"
    OUT_DIR: str = "output"
    OUT_DIR_COLORED: str = "output_colored"
    TITLE_CARD_DIR: str = "title_cards"
    FIGURE_DIR: str = "figures"
    ENDCARD_FILE_NAME: str = "endcard"

    # These values are saved between runs.
    internal_label_font_path: str | None = None
    terms_file_path: str | None = None

    def __str__(self):
        """
        Dump the names and values as a table.

        :return: A string representation of the config.
        """
        return "\n".join(f"{name}: {value}" for name, value in asdict(self).items())


def get_config_path() -> Path:
    """
    Get the directory where the config file is stored.
    """
    # Use the XDG standard for the config directory.
    # https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html
    return XDG_CONFIG_HOME / "slime_builder.json"


def load_config() -> Config:
    """
    Load the config file.
    """
    logger.debug("Loading config file.")
    config_file = get_config_path()
    if config_file.exists():
        with open(config_file, "r") as f:
            # Fault tolerant loading. Try to find keys in the config file that
            # are in the config class, and ignore the rest.
            try:
                config_dict = json.load(f)
            except json.JSONDecodeError as e:
                logger.error("Could not parse config file.")
                logger.exception(e)
                return Config()
            except OSError as e:
                logger.error("Could not load config file.")
                logger.exception(e)
                return Config()
            config = Config()
            for key, value in config_dict.items():
                if hasattr(config, key):
                    setattr(config, key, value)
            logger.debug("Loaded config file.")
            return config
    else:
        logger.info("No config file found. Using default values.")
        return Config()


def save_config(config: Config):
    """
    Save the config file.
    """
    logger.debug("Saving config file.")
    config_file = get_config_path()
    try:
        with open(config_file, "w") as f:
            json.dump(asdict(config), f, indent=4)
    except OSError as e:
        logger.error(f"Could not save config file")
        logger.exception(e)
