import os
import shutil
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import Any, Optional

import slime_builder.helpers as hp


class CliState(Enum):
    """
    Abstract enum for the states of the different CLI interfaces.
    """

    pass


def get_input_validated(
    prompt: str,
    expected_type: type,
    state_next: CliState,
    state_prev: CliState,
    state_quit: CliState,
    int_max: Optional[int] = None,
) -> tuple[Any, CliState]:
    """
    Get input from the user and validate it.
    If the user inputs "back", return the previous state.
    If the user inputs "quit", return the quit state.
    Asks repeatedly until the input is valid.

    :param prompt: The prompt to display to the user.
    :param expected_type: The expected type of the input.
    :param state_next: The state to go to after the input is validated.
    :param state_prev: The state to go to if the user inputs "back".
    :param state_quit: The state to go to if the user inputs "quit".
    :param int_max: The maximum value to optionally accept for an integer input.
    :return: The input, and the state to go to.
    """
    while True:
        user_input = input(prompt)
        if user_input.lower() == "back":
            return None, state_prev
        elif user_input.lower() == "quit":
            return None, state_quit
        # Attempt to convert the input to the expected type.
        try:
            user_input = expected_type(user_input)
        except ValueError:
            print(f"Invalid input. Expected type {expected_type.__name__}.")
            continue
        # If the input is an integer, check if it's within the max value.
        if expected_type is int and int_max is not None:
            if user_input > int_max or user_input <= 0:
                print(f"Invalid input. Expected an integer between 1 and {int_max}.")
                continue
        # All checks passed, return good input and the next state.
        return user_input, state_next


def get_confirmation(prompt: str, default: Optional[bool] = None) -> bool:
    """
    Get confirmation from the user.
    Repeat if the input wasn't valid.

    :param prompt: The prompt to display to the user.
    :param default: The default value to return if the user doesn't input anything.
    :return: The user's confirmation.
    """
    match default:
        case None:
            prompt += " [y/n]"
        case True:
            prompt += " [Y/n]"
        case False:
            prompt += " [y/N]"

    prompt += " > "

    while True:
        user_input = input(prompt)
        if user_input.lower().strip().startswith("y"):
            return True
        elif user_input.lower().strip().startswith("n"):
            return False
        elif user_input == "" and default is not None:
            return default
        else:
            print("Invalid input. Please try again.")


class CliOptions:
    """
    Unified representation of options for the CLI.
    Save text labels and their linked data values.
    Automatically numbers the options when printed.
    This acts as a wrapper for an otherwise oddly nested structure.
    """

    _data: list[tuple[str, Any]]

    def __init__(self, options: list[tuple[str, Any]]):
        """
        Initialize the options with linked data.

        :param options: The options to initialize with: prompt, linked data.
        """
        self._data = options

    def add_option(self, option: Any, linked_data: Any) -> None:
        """
        Add an option to the list of options.
        """
        self._data.append((option, linked_data))

    def print_options(self, prompt: str) -> None:
        """
        Print the list of options to the user.

        :param prompt: The prompt to display to the user.
        """
        print(prompt, "(back, quit)")
        for i, (option, linked_data) in enumerate(self._data):
            print(f"{i + 1}: {option}")

    def get_linked_data(self, index: int) -> Any:
        """
        Get the linked data of the option at the given index.
        Unlike when printed, this is 0-indexed.

        :param index: The index of the option to get the linked data of, 0-indexed.
        :return: The linked data of the option at the given index.
        """
        return self._data[index][1]

    def labels(self):
        return [option for option, _ in self._data]

    def valid_index(self, index: int) -> bool:
        """
        Check if the given index is a valid option.

        :param index: The index to check.
        :return: True if the index is valid, False otherwise.
        """
        return 0 <= index < len(self._data)

    def prompt(
        self,
        prompt: str,
        state_next: CliState,
        state_prev: CliState,
        state_quit: CliState,
    ) -> tuple[Any, CliState]:
        """
        Print the prompt and the list of options to the user.
        The user may either select an option numerically or by matching the string.
        If the string isn't an exact match, the user is prompted to confirm if the
        closest match was meant.
        Repeat until the user selects a valid option.
        Alternatively, the user may go back or quit by typing 'back' or 'quit'.

        :param prompt: The prompt to display to the user.
        :param state_next: The state to progress to if the user selects an option.
        :param state_prev: The state to progress to if the user selects 'back'.
        :param state_quit: The state to progress to if the user selects 'quit'.
        :return: The linked data of the selected option and the state to progress to.
                 If the user selects 'back' or 'quit', the linked data is None.
        """

        self.print_options(prompt)
        while True:
            user_input = input("> ")
            try:
                index = int(user_input) - 1  # Make 0-indexed.
                if self.valid_index(index):
                    return self.get_linked_data(index), state_next
                else:
                    print("Invalid option. Please try again.")
            except ValueError:
                # The user input was a string.
                # Test for command words, then exact matches, and lastly try to find a close match.
                if user_input == "back":
                    return None, state_prev

                elif user_input == "quit":
                    return None, state_quit

                elif user_input in self.labels():
                    return (
                        self.get_linked_data(self.labels().index(user_input)),
                        state_next,
                    )

                else:
                    # Find the closest match.
                    closest_match = hp.closest_match(user_input, self.labels())
                    if closest_match is not None:
                        if get_confirmation(f'Did you mean "{closest_match}"?', default=True):
                            return (
                                self.get_linked_data(self.labels().index(closest_match)),
                                state_next,
                            )
                    else:
                        print("Invalid option. Please try again.")

    def __len__(self):
        return len(self._data)

    def __repr__(self):
        return f"{self.__class__.__name__}({self._data})"

    def __str__(self):
        return self.__repr__()


def notify_if_dir_not_empty(directory: Path, required: bool = False) -> None:
    # Check if the dir is empty, otherwise prompt the user.
    # Abort if the user denies, only is required is True.
    while os.listdir(directory):
        if not required:
            if get_confirmation(f'The folder "{directory}" is not empty. Proceed anyway?)', True):
                break
            else:
                sys.exit(0)
        else:
            if get_confirmation(
                f'Please ensure the folder "{directory}" is empty. Try again?', True
            ):
                continue
            else:
                sys.exit(0)


def ask_then_delete(target_dir) -> bool:
    """
    Ask to delete a directory.
    On Linux, check if trash-cli is installed and offer to trash the item instead.
    If that fails, ask to delete it.

    :param target_dir:
    :return: True if the directory was deleted.
    """

    if shutil.which("trash"):
        if get_confirmation(f"{target_dir} already exists. Move to trash?", default=True):
            if subprocess.run(["trash-put", str(target_dir)]).returncode == 0:
                return True
            else:
                print("Failed to move to trash.")

    if get_confirmation(f"{target_dir} already exists. Do you want to delete it?", default=False):
        shutil.rmtree(target_dir)

    # Perform a final check to see if the directory was deleted.
    return not target_dir.exists()
