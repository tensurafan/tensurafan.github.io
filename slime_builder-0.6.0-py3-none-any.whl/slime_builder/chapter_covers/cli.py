from importlib import resources
import os
import subprocess
from enum import auto, Enum
from pathlib import Path
from typing import Optional
import slime_builder.chapter_covers.templates

import slime_builder.chapter_covers.generator as generator
import slime_builder.cli as cli


def main():
    # Start interactive CLI
    class CoverState(cli.CliState):
        InputDirectory = auto()
        SelectType = auto()
        InputTitle = auto()
        InputNumber = auto()
        DoGeneration = auto()
        Quit = auto()

    class ChapterType(Enum):
        Prologue = auto()
        Chapter = auto()
        Interlude = auto()
        Epilogue = auto()

    generator_types = cli.CliOptions(
        [
            ("Prologue", ChapterType.Prologue),
            ("Chapter", ChapterType.Chapter),
            ("Interlude", ChapterType.Interlude),
            ("Epilogue", ChapterType.Epilogue),
        ]
    )

    output_dir = Path(os.getcwd())
    chapter_type = None
    chapter_title: str = ""
    chapter_number: Optional[int] = None
    state = CoverState.InputDirectory

    while state != CoverState.Quit:
        match state:
            case CoverState.InputDirectory:
                print("Current directory:", output_dir)
                if cli.get_confirmation("Change directory?", default=False):
                    output_dir, state = cli.get_input_validated(
                        "Enter a new directory: ",
                        expected_type=str,
                        state_next=CoverState.SelectType,
                        state_prev=CoverState.Quit,
                        state_quit=CoverState.Quit,
                    )
                    try:
                        output_dir = Path(output_dir)
                        output_dir = output_dir.expanduser()
                        print("New directory:", output_dir)
                    except ValueError:
                        print("Invalid directory\n")
                        state = CoverState.InputDirectory
                else:
                    state = CoverState.SelectType

            case CoverState.SelectType:
                chapter_type, state = generator_types.prompt(
                    "Select a type of chapter cover to generate: ",
                    state_next=CoverState.InputTitle,
                    state_prev=CoverState.InputDirectory,
                    state_quit=CoverState.Quit,
                )

            case CoverState.InputTitle:
                chapter_title, state = cli.get_input_validated(
                    "Enter the title of the chapter: ",
                    expected_type=str,
                    state_next=CoverState.InputNumber,
                    state_prev=CoverState.InputDirectory,
                    state_quit=CoverState.Quit,
                )

            case CoverState.InputNumber:
                if chapter_type != ChapterType.Chapter:
                    state = CoverState.DoGeneration
                    continue

                chapter_number, state = cli.get_input_validated(
                    "Enter the chapter number: ",
                    expected_type=int,
                    state_next=CoverState.DoGeneration,
                    state_prev=CoverState.InputTitle,
                    state_quit=CoverState.Quit,
                )

            case CoverState.DoGeneration:
                # Set the template name and output path.
                match chapter_type:
                    case ChapterType.Prologue:
                        template_name = "PrologueTemplate.svg"
                        png_path = output_dir / "Prologue.png"
                    case ChapterType.Chapter:
                        template_name = "ChapterTemplate.svg"
                        png_path = output_dir / f"Chapter{chapter_number}.png"
                    case ChapterType.Interlude:
                        template_name = "InterludeTemplate.svg"
                        png_path = output_dir / "Interlude.png"
                    case ChapterType.Epilogue:
                        template_name = "EpilogueTemplate.svg"
                        png_path = output_dir / "Epilogue.png"
                    case _:
                        raise ValueError("Invalid chapter type")

                with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
                    template_path = templates_dir / template_name

                # noinspection PyTypeChecker
                generate_cover(chapter_title, chapter_number, template_path, png_path)
                print(f"Generated {png_path}")
                state = CoverState.SelectType


def generate_cover(chapter_title: str, chapter_number: int, template_path: Path, png_path: Path):
    command = f'sed -e "{generator.make_sed_pattern(chapter_title, chapter_number)}" {template_path} | inkscape --pipe --export-filename="{png_path}"'
    subprocess.run(command)


if __name__ == "__main__":
    main()
