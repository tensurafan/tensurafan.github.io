from importlib import resources
import shutil
from pathlib import Path
from typing import Optional
import slime_builder.chapter_covers.templates
import subprocess
from logzero import logger


def make_sed_pattern(
    chapter_title: str,
    chapter_number: Optional[int] = None,
    background_color: str | None = None,
) -> str:
    """
    Create a sed pattern to replace the placeholders in the template with the chapter title and number.
    Split chapter title along "\n" and distribute the lines among all 4 tags:
    #TEXT1#, #TEXT2#, #TEXT3# and #TEXT4#. If there is no text to replace it, replace it with "".
    Replace the #NUMBER# placeholder with the chapter number, if given.

    :param chapter_title: The title of the chapter to generate a cover for.
    :param chapter_number: [Optional] The chapter number to generate a cover for.
    :param background_color: [Optional] The background color to use for the cover,
        give a hex color like "aa22cc". By default it doesn't change.
    :return: The sed pattern.
    """
    text_lines = (chapter_title + "\n" * 4).split("\n")
    text_lines = text_lines[:4]
    text_lines = [line if line != "" else " " for line in text_lines]

    sed_pattern = f"s/#TEXT1#/{text_lines[0]}/ ; s/#TEXT2#/{text_lines[1]}/ ; s/#TEXT3#/{text_lines[2]}/ ; s/#TEXT4#/{text_lines[3]}/"

    if chapter_number is not None:
        sed_pattern += f" ; s/#NUMBER#/{chapter_number}/"

    if background_color is not None:
        sed_pattern += f" ; s/#000000/#{background_color}/"

    return sed_pattern


def patch_svg(
    template_path: str,
    chapter_title: str,
    chapter_number: Optional[int] = None,
    background_color: str | None = None,
) -> str:
    """
    Read and patch the svg template with the given data.

    Format for the template:
    #TEXT1#, #TEXT2#, #TEXT3# and #TEXT4# are the text lines.
    If there are less than 4 lines, the remaining ones are empty.
    More than 4 lines are ignored.
    #NUMBER# is the chapter number.
    #000000# is the background color.

    :param template_path: The path to the svg template.
    :param chapter_title: The title of the chapter to generate a cover for.
    :param chapter_number: [Optional] The chapter number to generate a cover for.
    :param background_color: [Optional] The background color to use for the cover.
    :return: Raw xml data of the patched svg.
    """
    with open(template_path, "r") as template_file:
        template = template_file.read()

    text_lines = (chapter_title + "\n" * 4).split("\n")
    text_lines = text_lines[:4]
    text_lines = [line if line != "" else " " for line in text_lines]

    template = template.replace("#TEXT1#", text_lines[0])
    template = template.replace("#TEXT2#", text_lines[1])
    template = template.replace("#TEXT3#", text_lines[2])
    template = template.replace("#TEXT4#", text_lines[3])

    if chapter_number is not None:
        template = template.replace("#NUMBER#", str(chapter_number))

    if background_color is not None:
        template = template.replace("#000000", "#" + background_color)

    return template


def optimize_png(path: Path) -> None:
    """
    Optimize a png file using optipng.

    :param path: The path to the png file to optimize.
    """
    # Check that optipng is installed.
    if not shutil.which("optipng"):
        logger.warning("optipng is not installed, skipping chapter card optimization.")
        return
    logger.debug(f"Optimizing {path}")
    subprocess.run(["optipng", "-quiet", str(path)])


def generate_chapter_cover(
    chapter_title: str,
    chapter_number: int,
    output_dir: Path,
    background_color: str | None = None,
    overwrite: bool = False,
    optimize: bool = True,
) -> None:
    """
    Use pipes and unix utils.

    :param chapter_title: The title of the chapter to generate a cover for.
    :param chapter_number: The chapter number to generate a cover for.
    :param output_dir: The output directory to save the generated cover to.
    :param background_color: [Optional] The background color to use for the cover.
    :param overwrite: [Optional] Whether to overwrite existing files.
    :param optimize: [Optional] Whether to optimize the generated png file.
    """
    template_name = "ChapterTemplate.svg"
    with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
        template_path = str(templates_dir / template_name)

    if output_dir.is_dir():
        output_dir = output_dir / f"Chapter{chapter_number}.png"

    # Check if the file already exists.
    if output_dir.is_file() and not overwrite:
        logger.debug(f"File {output_dir} already exists, skipping.")
        return

    logger.info(
        f"Generating chapter cover for chapter {chapter_number}, title: {chapter_title.__repr__()}, background color: {background_color}"
    )

    patched_svg = patch_svg(template_path, chapter_title, chapter_number, background_color)

    inkscape_command = ["inkscape", "--pipe", "--export-filename=" + str(output_dir)]

    # Pipe the patched svg to inkscape.
    process = subprocess.Popen(
        inkscape_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    process.communicate(input=patched_svg.encode("utf-8"))

    # Logging the command.
    logger.debug(f"Generating: patched_svg | {' '.join(inkscape_command)}")

    if optimize:
        optimize_png(output_dir)


def generate_prologue_cover(
    chapter_title: str,
    output_dir: Path,
    background_color: str | None = None,
    overwrite: bool = False,
    optimize: bool = True,
) -> None:
    """
    Use pipes and unix utils.

    :param chapter_title: The title of the chapter to generate a cover for.
    :param output_dir: The output directory to save the generated cover to.
    :param background_color: [Optional] The background color to use for the cover.
    :param overwrite: [Optional] Whether to overwrite existing files.
    :param optimize: [Optional] Whether to optimize the generated png file.
    """
    template_name = "PrologueTemplate.svg"
    with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
        template_path = str(templates_dir / template_name)

    if output_dir.is_dir():
        output_dir = output_dir / f"Prologue.png"

    # Check if the file already exists.
    if output_dir.is_file() and not overwrite:
        logger.debug(f"File {output_dir} already exists, skipping.")
        return

    logger.info(
        f"Generating prologue cover for title: {chapter_title.__repr__()}, background color: {background_color}"
    )

    patched_svg = patch_svg(template_path, chapter_title, background_color=background_color)

    inkscape_command = ["inkscape", "--pipe", "--export-filename=" + str(output_dir)]

    # Pipe the patched svg to inkscape.
    process = subprocess.Popen(
        inkscape_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    process.communicate(input=patched_svg.encode("utf-8"))

    # Logging the command.
    logger.debug(f"Generating: patched_svg | {' '.join(inkscape_command)}")

    if optimize:
        optimize_png(output_dir)


def generate_interlude_cover(
    chapter_title: str,
    output_dir: Path,
    background_color: str | None = None,
    overwrite: bool = False,
    optimize: bool = True,
) -> None:
    """
    Use pipes and unix utils.

    :param chapter_title: The title of the chapter to generate a cover for.
    :param output_dir: The output directory to save the generated cover to.
    :param background_color: [Optional] The background color to use for the cover.
    :param overwrite: [Optional] Whether to overwrite existing files.
    :param optimize: [Optional] Whether to optimize the generated png file.
    """
    template_name = "InterludeTemplate.svg"
    with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
        template_path = str(templates_dir / template_name)

    if output_dir.is_dir():
        output_dir = output_dir / f"Interlude.png"

    # Check if the file already exists.
    if output_dir.is_file() and not overwrite:
        logger.debug(f"File {output_dir} already exists, skipping.")
        return

    logger.info(
        f"Generating interlude cover for title: {chapter_title.__repr__()}, background color: {background_color}"
    )

    patched_svg = patch_svg(template_path, chapter_title, background_color=background_color)

    inkscape_command = ["inkscape", "--pipe", "--export-filename=" + str(output_dir)]

    # Pipe the patched svg to inkscape.
    process = subprocess.Popen(
        inkscape_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    process.communicate(input=patched_svg.encode("utf-8"))

    # Logging the command.
    logger.debug(f"Generating: patched_svg | {' '.join(inkscape_command)}")

    if optimize:
        optimize_png(output_dir)


def generate_epilogue_cover(
    chapter_title: str,
    output_dir: Path,
    background_color: str | None = None,
    overwrite: bool = False,
    optimize: bool = True,
) -> None:
    """
    Use pipes and unix utils.

    :param chapter_title: The title of the chapter to generate a cover for.
    :param output_dir: The output directory to save the generated cover to.
    :param background_color: [Optional] The background color to use for the cover.
    :param overwrite: [Optional] Whether to overwrite existing files.
    :param optimize: [Optional] Whether to optimize the generated png file.
    """
    template_name = "EpilogueTemplate.svg"
    with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
        template_path = str(templates_dir / template_name)

    if output_dir.is_dir():
        output_dir = output_dir / f"Epilogue.png"

    # Check if the file already exists.
    if output_dir.is_file() and not overwrite:
        logger.debug(f"File {output_dir} already exists, skipping.")
        return

    logger.info(
        f"Generating epilogue cover for title: {chapter_title.__repr__()}, background color: {background_color}"
    )

    patched_svg = patch_svg(template_path, chapter_title, background_color=background_color)

    inkscape_command = ["inkscape", "--pipe", "--export-filename=" + str(output_dir)]

    # Pipe the patched svg to inkscape.
    process = subprocess.Popen(
        inkscape_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    process.communicate(input=patched_svg.encode("utf-8"))

    # Logging the command.
    logger.debug(f"Generating: patched_svg | {' '.join(inkscape_command)}")

    if optimize:
        optimize_png(output_dir)


def generate_story_cover(
    story_title: str,
    story_number: int,
    output_dir: Path,
    background_color: str | None = None,
    overwrite: bool = False,
    optimize: bool = True,
) -> None:
    """
    Use pipes and unix utils.

    :param story_title: The title of the story to generate a cover for.
    :param story_number: The number of the story to generate a cover for.
    :param output_dir: The output directory to save the generated cover to.
    :param background_color: [Optional] The background color to use for the cover.
    :param overwrite: [Optional] Whether to overwrite existing files.
    :param optimize: [Optional] Whether to optimize the generated png file.
    """
    template_name = "StoryTemplate.svg"
    with resources.files(slime_builder.chapter_covers.templates) as templates_dir:
        template_path = str(templates_dir / template_name)

    if output_dir.is_dir():
        output_dir = output_dir / f"Chapter{story_number}.png"

    # Check if the file already exists.
    if output_dir.is_file() and not overwrite:
        logger.debug(f"File {output_dir} already exists, skipping.")
        return

    logger.info(
        f"Generating story cover for title: {story_title.__repr__()}, number: {story_number}, background color: {background_color}"
    )

    patched_svg = patch_svg(
        template_path, story_title, story_number, background_color=background_color
    )

    inkscape_command = ["inkscape", "--pipe", "--export-filename=" + str(output_dir)]

    # Pipe the patched svg to inkscape.
    process = subprocess.Popen(
        inkscape_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    process.communicate(input=patched_svg.encode("utf-8"))

    # Logging the command.
    logger.debug(f"Generating: patched_svg | {' '.join(inkscape_command)}")

    if optimize:
        optimize_png(output_dir)
