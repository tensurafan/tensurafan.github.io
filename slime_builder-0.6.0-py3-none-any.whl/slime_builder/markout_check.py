"""
Validate the markout files contain the necessary information.
Checks that links are valid.
Checks that tags are valid.
Validate the style and formatting of the markout files.
Heuristically analyze the English text.
"""


import sys
import re
import codecs
from enum import Enum, auto
from pathlib import Path
from logzero import logger
import slime_builder.helpers as hp
import slime_builder.cli as cli
from slime_builder.cli_messages import MoError, MoWarning

NORMALIZATION: dict = {
    "“": '"',
    "”": '"',
    "‘": "'",
    "’": "'",
    "…": "...",
    "–": "---",
    "—": "---",
    "«": "<<",
    "»": ">>",
    "‹": "<",
    "›": ">",
}

# I <3 Regex.
REGEX_VALID_BEGINNINGS = re.compile(
    r"^\*?(<?<?'?\"?( \")*'?(---|\.\.\.)?([A-Z]|'?\"?>?>?$)|(---|\.\.\.)([^ ]|$)|> ?)"
)
REGEX_VALID_ENDINGS = re.compile(
    r"((([.,!?~]|\.\.\.|---)'?\"?>?>?)|(\" \")|([:*])|\^\[[^[]+]'?\"?>?>?|(?=^)>)|(YES/NO>>)$"
)
REGEX_ILLEGAL_CHARS = re.compile(
    r"[^ ,;.:\-_a-zA-Z0-9éèêàōïü\"'^~*/()<>&!?™\[\]ぁ-ヺ丁-𫠝]+|(?<!~)~(?!~)"
)
REGEX_BAD_PUNCTUATION = re.compile(r"!\?|[^.'\"<]\.\.[^.]|(---[.,;:-]+)|([,;]{2,})| {2,}")
REGEX_UNCAP_START = re.compile(r"^([a-z]|((\"|---)[a-z]))")
REGEX_UNCAP = re.compile(r"(?<!\.\.)\. ?[a-z]")
REGEX_NO_SPACE = re.compile(r"( ?(?<!\.\.)\.|,)[a-zA-Z]")
REGEX_INV_ELLIPSIS = re.compile(r"\w+\.\.\.(( [a-z])|[.]+)")


def check_project(project_path: Path, errors_only: bool, image_dir: str):
    """
    Check the project at the given path.
    :param project_path: The path to the project or an individual file.
    :param errors_only: Suppress warnings.
    :param image_dir: The directory containing the images.
    """

    # If the path is a directory, check all the files in it.
    if project_path.is_dir():
        # Markout files have no extension.
        file_paths = list(
            f
            for f in project_path.glob("*")
            if f.is_file() and not f.suffix and not f.name.startswith(".")
        )
    elif project_path.is_file():
        file_paths = [project_path] if not project_path.suffix else []
    else:
        logger.error(f"Invalid path: {project_path} does not exist.")
        sys.exit(1)

    if not file_paths:
        logger.error(f"No markout files found in {project_path}")
        sys.exit(1)

    file_paths.sort()

    # List files being checked.
    logger.info(
        f"Checking {len(file_paths)} files in {project_path}:\n"
        + "\t\n".join(f.name for f in file_paths)
    )

    # Separate files into chapters and masters.
    chapter_paths = []
    master_paths = []
    for file_path in file_paths:
        if file_path.name.lower() == "master":
            master_paths.append(file_path)
        else:
            chapter_paths.append(file_path)

    if len(master_paths) == 0 and len(chapter_paths) > 0:
        MoError.print("No master file found.", project_path)
    elif len(master_paths) > 1:
        MoError.print("Multiple master files found.", project_path)

    logger.info(
        f"Found {len(master_paths)} master {hp.f_plural(len(master_paths), 'file', 'files')} and "
        f"{len(chapter_paths)} chapter {hp.f_plural(len(chapter_paths), 'file', 'files')}."
    )

    # Normalize the files.
    normalize_project(file_paths)

    issues: list[MoError | MoWarning] = []

    # Integrity checks.
    for file in master_paths:
        issues += check_master(file)

    for file in chapter_paths:
        issues += check_chapter(file)

    # Link checks.
    for file in file_paths:
        issues += check_links(file, project_path, image_dir)

    warnings = [issue for issue in issues if isinstance(issue, MoWarning)]
    errors = [issue for issue in issues if isinstance(issue, MoError)]

    def print_issues(_issues: list[MoError | MoWarning], type_singular: str, type_plural: str):
        logger.info(
            f"Found {len(_issues)} {hp.f_plural(len(_issues), type_singular, type_plural)}:\n"
        )
        prev_file: str | None = None
        for issue in _issues:
            if issue.file_name != prev_file:
                f_name_spaced = f" {issue.file_name} "
                print(f"\n{f_name_spaced:=^70}")
                prev_file = issue.file_name
            print(issue)

    if warnings and not errors_only:
        print_issues(warnings, "warning", "warnings")

    if errors:
        print_issues(errors, "error", "errors")

    warnings_message = f"{len(warnings)} {hp.f_plural(len(warnings),'Warning', 'Warnings')}"
    errors_message = f"{len(errors)} {hp.f_plural(len(errors), 'Error', 'Errors')}"
    summary_message = f"\n{'-'*40}\nSummary: "
    if not errors_only:
        print(f"{summary_message}{warnings_message} and {errors_message}.")
    else:
        print(f"{summary_message}{errors_message}.")


def normalize_project(file_paths: list[Path]):
    """
    Check for normalization for all files in the list.
    This is to catch special characters that may theoretically work, but are not recommended.

    If violations are found, the user is prompted to normalize the files.
    If the user refuses to normalize, the program will exit.

    :param file_paths: The list of files to check.
    """
    issues = []
    for file_path in file_paths:
        text = file_path.read_text()
        issues += check_normalization(text, file_path.name, file_path)

    if not issues:
        return

    logger.error("Normalization issues found:")
    for issue in issues:
        print(issue)
    logger.error(
        f"Found {len(issues)} normalization {hp.f_plural(len(issues), 'issue', 'issues')}."
    )
    if cli.get_confirmation("Normalize files?"):
        for file_path in file_paths:
            normalize_file(file_path)
            logger.debug(f"Normalized {file_path.name}.")
        logger.info("Files normalized.")
        return

    logger.info("Normalization cancelled.")
    sys.exit(0)


def check_master(master_path: Path) -> list[MoError | MoWarning]:
    """
    Check the master at the given path.
    :param master_path: The path to the master.
    """
    file_name = master_path.name
    lines = hp.strip_comments(master_path.read_text()).splitlines()

    issues: list[MoError | MoWarning] = []

    def error(*arg):
        issues.append(MoError(*arg))

    # Expect these sections in this order.
    class Stage(Enum):
        COVER = auto()
        TITLE = auto()
        VOLUME_NUMBER = auto()
        CREDITS = auto()
        DISCLAIMER = auto()
        EDITION = auto()
        ARC = auto()
        INCLUDES = auto()

    stage = Stage.COVER

    tag_count: dict[Stage, int] = {stage: 0 for stage in Stage}

    for i, line in enumerate(lines, start=1):

        if not line:
            continue

        # Check each tag that can be encountered first, ensuring they aren't out of order.

        # The cover has this syntax: ![cover](cover.jpg)
        if re.match(r"!\[cover](\(.+\))?", line):
            tag_count[Stage.COVER] += 1
            if i == 1:
                # Check for the cover image.
                stage = Stage.TITLE
            else:
                error("Cover tag must be on the first line.", file_name, line, i)
        # Title tag: ?[title](Title)
        elif re.match(r"\?\[title]\(.+\)", line):
            tag_count[Stage.TITLE] += 1
            if stage != Stage.TITLE:
                error("Title tag out of order.", file_name, line, i)
            else:
                stage = Stage.VOLUME_NUMBER
        # Volume number tag: ?[volume](1)
        elif re.match(r"\?\[volume]\(.+\)(\{.*})?", line):
            tag_count[Stage.VOLUME_NUMBER] += 1
            if stage != Stage.VOLUME_NUMBER:
                error("Volume number tag out of order.", file_name, line, i)
            else:
                stage = Stage.CREDITS
        # Credits don't have a tag, but their end is marked by the disclaimer tag.
        # Disclaimer tag: ![disclaimer]
        elif re.match(r"!\[disclaimer]", line):
            tag_count[Stage.DISCLAIMER] += 1
            # Skipping the disclaimer stage, because the credit section has undefined length.
            # Therefore we still assume the user is in the credits section.
            if stage != Stage.CREDITS:
                error("Credits out of order.", file_name, line, i)
            else:
                stage = Stage.EDITION
        # Edition tag: ?[edition](Edition)
        elif re.match(r"\?\[edition]\(.+\)", line):
            tag_count[Stage.EDITION] += 1
            if stage != Stage.EDITION:
                error("Edition tag out of order.", file_name, line, i)
            else:
                stage = Stage.ARC
        # Arc tag: ?[arc](Arc)
        elif re.match(r"\?\[arc]\(.+\)", line):
            tag_count[Stage.ARC] += 1
            if stage != Stage.ARC:
                error("Arc tag out of order.", file_name, line, i)
            else:
                stage = Stage.INCLUDES
        # Includes tag: ![include](Includes)
        elif re.match(r"!\[include]\(.+\)", line):
            tag_count[Stage.INCLUDES] += 1
            if stage != Stage.INCLUDES:
                error("Includes tag out of order.", file_name, line, i)
            # It's the last stage.
        else:
            # Check if the line is a break or image.
            # Breaks are only allowed in the credits section.
            # Break tag: ![break]
            if re.match(r"!\[break]", line):
                if stage != Stage.CREDITS:
                    error("Break tags are only allowed in the credits section.", file_name, line, i)
            # An image is only allowed in the cover section.
            # Image tag:
            # ![full page image](image name.jpg){alt text}
            # ![exact fit image](image name.jpg){alt text}
            if re.match(r"!\[(full page image|exact fit image)]\(.+\)(\{.+})?", line):
                if stage != Stage.TITLE:
                    error(
                        "Image tags are only permitted right after the cover.", file_name, line, i
                    )
            # Check if it's a color-edition-only tag. These also belong in the credits section.
            # Color edition only tag: ?[color edition only](text)
            elif re.match(r"\?\[color edition only]\(.+\)", line):
                if stage != Stage.CREDITS:
                    error(
                        "Color edition only tags are only allowed in the credits section.",
                        file_name,
                        line,
                        i,
                    )
            # Check if it's a malformed tag.
            elif match := re.match(r"[!?]\[.+]\(.+\)?", line):
                error("Malformed tag.", file_name, line, i, match)
            else:
                # Suppose it's a line of text. These belong in the credits section.
                if stage != Stage.CREDITS:
                    error("Text outside of the credits section.", file_name, line, i)

    return issues


def has_bom(filename):
    """
    Returns True if the file at the specified path has a BOM, False otherwise.
    """
    with open(filename, "rb") as file:
        bom = file.read(4)
        return bom.startswith(codecs.BOM_UTF8)


def remove_bom(filename):
    """
    Removes the BOM from the file at the specified path, if present.
    """
    if has_bom(filename):
        with codecs.open(filename, "r", encoding="utf-8-sig") as file:
            text = file.read()
        with open(filename, "w") as file:
            file.write(text)


def check_normalization(text: str, file_name: str, file_path: Path):
    """
    Check that the text is normalized.
    :param text: The text to check.
    :param file_name: The name of the file being checked.
    :param file_path: The path to the file being checked.
    """
    logger.debug(f"Checking normalization of {file_name}.")
    issues: list[MoError | MoWarning] = []

    def error(*arg):
        issues.append(MoError(*arg))

    re_un_normalized = re.compile(f"[{''.join(NORMALIZATION.keys())}]+")
    re_un_stripped = re.compile(r"^\s+|\s+$")

    # Check for BOM bytes.
    if has_bom(file_path):
        error("File has UTF-8 BOM bytes.", file_name)

    lines = text.splitlines()
    for i, line in enumerate(lines, start=1):
        for match in re_un_normalized.finditer(line):
            error(f"Un-normalized {match.group()}", file_name, line, i, match)
        for match in re_un_stripped.finditer(line):
            error(f"Illegal whitespace", file_name, line, i, match)

    return issues


def normalize_file(file_path: Path):
    """
    Normalize the file at the given path.
    :param file_path: The path to the file.
    """

    remove_bom(file_path)

    text = file_path.read_text()
    # Compile the regex string, but this time without the + to match individual characters,
    # so we can look them up in the normalization dictionary.
    re_un_normalized = re.compile(f"[{''.join(NORMALIZATION.keys())}]")
    # Replace all un-normalized characters with their normalized equivalents.
    text = re_un_normalized.sub(lambda m: NORMALIZATION[m.group()], text)
    # Remove all leading and trailing whitespace for each line.
    text = "\n".join(line.strip() for line in text.splitlines())

    file_path.write_text(text)


def check_chapter(chapter_path: Path) -> list[MoError | MoWarning]:
    """
    Check the chapter at the given path.
    :param chapter_path: The path to the chapter.

    :return: A list of errors and warnings.
    """
    file_name = chapter_path.name
    lines = hp.strip_comments(chapter_path.read_text()).splitlines()

    issues: list[MoError | MoWarning] = []

    def error(*arg):
        issues.append(MoError(*arg))

    def warning(*arg):
        issues.append(MoWarning(*arg))

    for i, line in enumerate(lines, start=1):

        # Check for valid headers.
        if i == 1:
            # Valid headers include:
            # (For interlude the number is optional, for prologue and epilogue it is banned.)
            # # Chapter X: chapter title
            # # Afterword
            # ![manga](image name.jpg){alt text}
            re_valid_chapter_header = re.compile(r"# Chapter \d+: [^#]+")
            re_valid_interlude_header = re.compile(r"# Interlude( \d+)?: [^#]+")
            re_valid_pro_epilogue_header = re.compile(r"# (Prologue|Epilogue): [^#]+")
            re_valid_afterword_header = re.compile(r"# Afterword$", flags=re.MULTILINE)
            re_valid_story_header = re.compile(r"# Story \d+: [^#]+")
            re_valid_manga_header = re.compile(r"!\[manga](\(.+\)({.+})?)?$", flags=re.MULTILINE)
            if not any(
                (
                    re_valid_chapter_header.match(line),
                    re_valid_interlude_header.match(line),
                    re_valid_pro_epilogue_header.match(line),
                    re_valid_afterword_header.match(line),
                    re_valid_story_header.match(line),
                    re_valid_manga_header.match(line),
                )
            ):
                error("Invalid header", file_name, line, i)
            continue

        # Skip empty lines.
        if not line:
            continue

        if line.startswith(("![", "?[", "[")):
            # Check if this is a valid tag for a chapter.
            # Images:
            # ![full page image](image name.jpg){alt text}
            # ![exact fit image](image name.jpg){alt text}
            # Note: the {alt text} is optional.
            # Breaks:
            # ![break]
            # ![soft scene break]
            # ![hard scene break]
            re_valid_images = re.compile(
                r"!\[(full page image|exact fit image)]\(.+\)(\{.+})?$", flags=re.MULTILINE
            )
            re_valid_breaks = re.compile(
                r"!\[(break|soft scene break|hard scene break)]$", flags=re.MULTILINE
            )

            if not re_valid_images.match(line) and not re_valid_breaks.match(line):
                error("-T- Invalid tag", file_name, line, i)

        elif line.startswith("- "):
            # handle lists.
            # They may be of the form:
            # - list item
            # - ?[label](item label) item text
            re_valid_list_item = re.compile(r"- +([^?][^[ ].*|\?\[label]\(.+\).*)")
            if not re_valid_list_item.match(line):
                error("-L- Invalid list item", file_name, line, i)

        else:
            for felon in REGEX_ILLEGAL_CHARS.finditer(line):
                warning(
                    f'-X-Illegal {hp.f_plural(len(felon.group()), "character", "characters")}',
                    file_name,
                    line,
                    i,
                    felon,
                )
            if match := REGEX_UNCAP_START.search(line):
                warning("-<-Uncapitalized start", file_name, line, i, match)
            if match := REGEX_UNCAP.search(line):
                warning("-.-Uncapitalized sentence", file_name, line, i, match)
            if match := REGEX_INV_ELLIPSIS.search(line):
                warning("-...-Invalid ellipsis", file_name, line, i, match)
            if match := REGEX_NO_SPACE.search(line):
                warning("-. -Wrong spacing around punctuation", file_name, line, i, match)
            if match := REGEX_BAD_PUNCTUATION.search(line):
                warning("-,.,-Invalid punctuation", file_name, line, i, match)
            if line.count('"') % 2 == 1:
                warning("-|-Unbalanced quotation marks", file_name, line, i)
            if line.count("*") % 2 == 1:
                warning("-|-Unbalanced asterisks", file_name, line, i)
            if line.count("<") != (line.count(">") - (1 if line.startswith(">") else 0)):
                # If the line starts with a >, this is inside a list paragraphs, so we don't
                # want to count that one.
                warning("-|-Unbalanced quotation marks", file_name, line, i)
            if line.count("(") != line.count(")"):
                warning("-|-Unbalanced parenthesis", file_name, line, i)
            if line.count("[") != line.count("]"):
                # This one is more severe since it could mean a malformed footnote.
                error("-|-Unbalanced brackets", file_name, line, i)
            if not REGEX_VALID_BEGINNINGS.match(line):
                warning("-^-Invalid line start", file_name, line, i)
            if not REGEX_VALID_ENDINGS.search(line):
                warning("-$-Invalid line ending", file_name, line, i)

    return issues


def check_links(file_path: Path, project_path: Path, image_dir: str) -> list[MoError]:
    """
    Check only image links and include references.

    :param file_path: The file to check.
    :param project_path: The project source files, serving as the reference root.
    :param image_dir: The directory containing the images.
    :return: Any Errors encountered.
    """
    file_name = file_path.name
    lines = file_path.read_text().splitlines()
    errors: list[MoError] = []

    def error(*arg):
        errors.append(MoError(*arg))

    # Check that the image dir exists.
    if not (project_path / image_dir).is_dir():
        error(f"Image directory does not exist: {image_dir}", file_name, image_dir)

    re_image_link = re.compile(
        r"!\[(cover|full page image|exact fit image|manga)]\((.+?)\)(\{.+})?"
    )
    re_include_link = re.compile(r"\[include]\((.+)\)")

    for i, line in enumerate(lines, start=1):
        if match := re_image_link.search(line):
            image_name = Path(match.group(2))
            for ext in ("", ".png", ".jpg", ".jpeg"):
                if (project_path / image_dir / image_name.with_suffix(ext)).is_file():
                    break
            else:
                error("Image not found", file_name, line, i, match.span(2))
        if match := re_include_link.search(line):
            include_name = match.group(1)
            if not (project_path / include_name).is_file():
                error("Included file not found", file_name, line, i, match.span(1))

    return errors
