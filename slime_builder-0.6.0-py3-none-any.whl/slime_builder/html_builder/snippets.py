from logzero import logger


def paragraph(text: str, add_space: bool = False, no_indent: bool = False) -> str:
    """
    Creates a paragraph.

    :param text: The text of the paragraph.
    :param add_space: Whether to add a space before the paragraph.
    :param no_indent: Whether to remove the indent from the paragraph.
    :return: A tag representing the paragraph.
    """

    tags = []
    if add_space:
        tags.append("space-break")
    if no_indent:
        tags.append("no-indent")
    classes = ' class="' + " ".join(tags) + '"' if tags else ""
    return f"<p{classes}>{text}</p>"


def image_tag(image_path: str, alt_text: str = "", is_manga: bool = False) -> str:
    """
    Creates an image tag.
    This is meant for regular, page-filling images.
    Manga images receive the manga anchor id.

    :param image_path: The image file name.
    :param alt_text: [Optional] The alt text for the image.
    :param is_manga: [Optional] Set to true if the image is a manga page.
    :return: A tag representing the image.
    """
    if alt_text is None:
        alt_text = ""

    if not is_manga:
        # language=HTML
        html = f'<div><img src="{image_path}" alt="{alt_text}" class="full"/></div><p class="pagebreak"></p>'
    else:
        # language=HTML
        html = f'<div><img src="{image_path}" alt="{alt_text}" class="full" id="manga"/></div><p class="pagebreak"></p>'
    return html


def soft_scene_break(figure_dir: str) -> str:
    """
    Creates a soft scene break.

    :param figure_dir: The directory containing the soft scene break image.
    :return: A tag representing the soft scene break.
    """

    # language=HTML
    html = (
        '\n<div class="scenebreak"><img class="ornament-soft" alt="Soft scene break." src="'
        + figure_dir
        + '/softscenebreak.png"/></div>\n'
    )
    return html


def hard_scene_break(figure_dir: str) -> str:
    """
    Creates a hard scene break.

    :param figure_dir: The directory containing the hard scene break image.
    :return: A tag representing the hard scene break.
    """

    # language=HTML
    html = (
        '\n<div class="scenebreak"><img class="ornament-hard" alt="Hard scene break." src="'
        + figure_dir
        + '/hardscenebreak.png"/></div>\n'
    )
    return html


def chapter_header(
    chapter_name: str, chapter_title: str, chapter_link: str, title_card_dir: str
) -> str:
    """
    Creates a chapter header.
    Includes an id link in the title card for linking to the chapter.

    :param chapter_name: The top row: Chapter 1, Prologue, etc.
    :param chapter_title: The bottom row: The chapter title.
    :param chapter_link: The file name of the chapter title card (without the extension).
    :param title_card_dir: The directory containing the title card images.
    :return:
    """

    # language=HTML
    return f"""<div><img src="{title_card_dir}/{chapter_link}.png" id="{chapter_link}" alt="" class="full"/></div>
    <p class="pagebreak"></p>
    <h1 class="ch-number">{chapter_name}</h1>
    <h1 class="ch-name">{chapter_title}</h1>
"""


def afterword_header() -> str:
    """
    Creates an afterword header.
    Also includes an id for linking to the afterword.

    :return: A tag representing the afterword header.
    """

    # language=HTML
    html = '<h1 class="afterword" id="afterword">Afterword</h1>\n'
    return html


def begin_list(data_list: bool) -> str:
    """
    Creates a list tag.

    :param data_list: Set to true when using labels.
    :return: A tag representing the list.
    """

    return "<dl>" if data_list else "<ul>"


def end_list(data_list: bool) -> str:
    """
    Creates an end list tag.

    :return: A tag representing the end of a list.
    """

    if data_list:
        html = "</dl>"
    else:
        html = "</ul>"
    return html


def list_item_start(label: str = None) -> str:
    """
    Opens a list item tag.

    :param label: [Optional] The label of the list item.
    :return: A tag representing the list item.
    """

    if label is None:
        # language=HTML
        html = f"<li>"
    else:
        # language=HTML
        html = f"<dt>{label}</dt><dd>"
    return html


def end_list_label(data_list: bool) -> str:
    """
    Creates an end list label tag.

    :return: A tag representing the end of a list label.
    """

    if data_list:
        html = "</dd>"
    else:
        html = "</li>"
    return html


# ======================================================================= Cover
def cover_page(cover_image) -> str:
    # language=HTML
    html = f"""<?xml version='1.0' encoding='utf-8'?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        
        <meta name="calibre:cover" content="true"/>
        <title>Cover</title>
        <style type="text/css" title="override_css">
            @page {{padding: 0pt; margin:0pt}}
            body {{ text-align: center; padding:0pt; margin: 0pt; }}
        </style>
    </head>
    <body>
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="100%" height="100%" viewBox="0 0 1350 1920" preserveAspectRatio="none">
                <image width="1350" height="1920" xlink:href="{cover_image}"/>
            </svg>
        </div>
    </body>
</html>"""
    return html


# ======================================================================= Credits


def credits_body(
    title: str,
    volume: str,
    color_edition: str,
    edition: str,
    credit_body: tuple[tuple[str, ...], ...],
) -> str:
    # language=HTML
    html = f"""\
<h1 class="title">{title}</h1>
<p class="subtitle">{volume}</p>
"""
    if color_edition:
        html += f'<p class="subtitle">{color_edition}</p>'

    # Add the edition to the end of the credit body.
    credit_body = (*credit_body, (edition,))

    for credit_paragraph in credit_body:
        first = True
        for credit_line in credit_paragraph:
            if first:
                # language=HTML
                html += f'\n\n<p class="credits-entry-space">{credit_line}</p>'
                first = False
            else:
                # language=HTML
                html += f'\n<p class="credits-entry">{credit_line}</p>'

    return html


# ======================================================================= Table of Contents
def toc(
    arc_name: str,
    contents: tuple[tuple[str, str], ...],
) -> str:
    """
    Creates a table of contents header.

    :param arc_name: The name of the arc.
    :param contents: The contents of the table of contents.
        A tuple of tuples, where the first item is the chapter file name and the second item is the chapter title.
    :return: A tag representing the table of contents header.
    """

    # language=HTML
    html = f"""<h1 class="toc-title">{arc_name}</h1>
    <h1 class="ch-name">Contents</h1>"""

    first = True
    for file_name, chapter_name in contents:
        if first:
            # language=HTML
            html += f'\n\n<p class="toc-chapter-space"><a href="{file_name}.xhtml" class="hlink">{chapter_name}</a></p>'
            first = False
        else:
            # language=HTML
            html += f'\n<p class="toc-chapter"><a href="{file_name}.xhtml" class="hlink">{chapter_name}</a></p>'

    return html


# ======================================================================= Footnotes


def footnote_reference(index: int) -> str:
    """
    Creates a footnote reference.

    :param index: The index of the footnote.
    :return: A tag representing the footnote reference.
    """

    # language=HTML
    html = f'<a href="notes.xhtml#note_{index}" class="no-deco" id="back_note_{index}"><sup>{index}</sup></a>'

    return html


def footnote_text(tex: str) -> str:
    """
    Creates a footnote paragraph out of latex.
    Note, only the class "note-text" needs to be applied,
    as well as handling latex \\ breaks.

    :param tex: The text of the footnote.
    :return: A tag representing the footnote text.
    """

    # language=HTML
    html = f'<p class="note-text">{tex}</p>'
    html = html.replace("\\\\", "<br/>")
    return html


def footnote_body(footnotes: list[tuple[int, str, str]]) -> str:
    """
    Creates the notes.html file body.

    :param footnotes: A list of tuples of the form (index, ref file name, text html).
    :return: html source
    """

    # language=HTML
    html = '<h1 class="title">Notes</h1>\n'

    for index, ref_file_name, text_html in footnotes:
        # language=HTML
        html += (
            f'\n<dl id="note_{index}" class="footnote">'
            f'<dt class="note-back">[<a href="{ref_file_name}.xhtml#back_note_{index}" class="no-deco">←{index}</a>]</dt>'
            f"<dd>{text_html}</dd></dl>"
        )

    return html


# ======================================================================= Wrappers


def wrap_story(body: str) -> str:
    """
    Package the body html into a formal html document.
    This is for story chapters.

    :param body: The body html.
    :return: The full html document.
    """

    return '<div class="story">\n' + body + "\n</div>\n"


def wrap_preamble(body: str) -> str:
    """
    Package the body html into a formal html document.
    This is for preamble.

    :param body: The body html.
    :return: The full html document.
    """

    return "<body>\n" + body + "\n</body>\n"


# ======================================================================= Slime Reader


def make_slime_reader_footnote(footnote_html: str) -> str:
    """
    Creates a footnote for the slime reader.
    The footnote text is expected to be fully escaped.

    :param footnote_html: The text of the footnote.
    :return: The html source.
    """

    # language=HTML
    return f"""<span class="icon color-primary color-in indent" data-hover-text="{footnote_html}" \
        onclick="this.app.showFootnote(this, this.getAttribute('data-hover-text'), event)"> \
        <span class="footnote clickable indent"></span></span>"""


def slime_reader_swappable_term(found_term: str, real_term: str, case_sensitive: bool) -> str:
    """
    Creates a term for the slime reader.
    Depending on the difference in capitalization, the term will have a converter attached.

    :param found_term: The term given in the text.
    :param real_term: The real term as defined in the glossary.
    :param case_sensitive: Whether the term is case sensitive.
    :return: The html source.
    """
    found_is_capitalized = found_term[0].isupper()

    # Check if all words are capitalized.
    found_is_capital_case = (
        all(word[0].isupper() for word in found_term.split(" ")) and len(found_term.split(" ")) > 1
    )
    found_is_capital_case_js_bool = "true" if found_is_capital_case else "false"

    if real_term != found_term and case_sensitive:
        logger.debug(f"Found term '{found_term}' is case sensitive, rejected.")
        return found_term

    displayed_term_value = "this.app.allTermsChosen[this.parentNode.dataset.term]"
    if real_term != found_term and found_is_capitalized:
        displayed_term_value = f"this.app.capitalCase(this.app.allTermsChosen[this.parentNode.dataset.term], {found_is_capital_case_js_bool})"
    elif real_term != found_term:
        displayed_term_value = "this.app.allTermsChosen[this.parentNode.dataset.term].toLowerCase()"

    return (
        f'<span class="clickable {{:this.app.getSupportingClasses(this):}}|{{otherConfigs.underlineChooseable}}|" '
        f'data-term="{real_term}" onclick="this.app.selectNameEventHandler(event)">'
        f"{{:{displayed_term_value}:}}|{{allTermsChosen[this.parentNode.dataset.term]}}|</span>"
    )


def term_hash_comment(hash_str: str) -> str:
    """
    Creates an html comment line containing the hash.

    :param hash_str: The hash of the comment.
    :return: The html source.
    """

    return f"<!-- terms.json::{hash_str} -->" + "\n"
