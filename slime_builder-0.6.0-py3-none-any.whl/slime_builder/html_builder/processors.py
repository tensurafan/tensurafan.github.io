import hashlib
import re
from pathlib import Path

import bs4
from logzero import logger

import slime_builder.html_builder.snippets as sp
import slime_builder.structures as st
from slime_builder.helpers import chapter_name_to_ref, check_image_suffixes


def master_latex_to_html(
    base_dir: Path, master: st.File, figure_dir: str, title_card_dir: str
) -> tuple[st.File, st.File, st.File]:
    """
    Convert the master latex file into 3 epub html files.

    :param base_dir: The base directory containing all files.
    :param master: The master file.
    :param figure_dir: The figure directory
    :param title_card_dir: The title card directory.
    :return: The insert, credits, and contents files.
    """

    # Get the insert + cover image.
    insert = "\n"
    insert += get_latex_master_section(master.content, "cover")
    insert += "\n\n"
    insert += get_latex_master_section(master.content, "insert")
    insert = chapter_latex_to_basic_html(insert, figure_dir, title_card_dir)
    insert = st.File(base_dir / "insert.xhtml", insert, init_read=False)

    # Get the metadata.
    title = latex_paragraph_to_html(get_latex_master_section(master.content, "title"))
    volume = latex_paragraph_to_html(get_latex_master_section(master.content, "volume"))
    edition = latex_paragraph_to_html(get_latex_master_section(master.content, "edition"))
    color_edition = latex_paragraph_to_html(
        get_latex_master_section(master.content, "coloredition")
    )
    raw_credits = get_latex_master_section(master.content, "credits")
    raw_disclaimer = get_latex_master_section(master.content, "disclaimer")
    raw_credits = raw_credits.replace(r"\disclaimer", raw_disclaimer)
    raw_credits = latex_paragraph_to_html(resolve_symbols(raw_credits))
    # Remove blank lines from raw credits and split it into separate tuples when encountering \creditspace.
    credit_body = []
    cred_buffer = []
    for line in raw_credits.splitlines():
        line = line.strip()
        if not line:
            continue
        if line == r"\creditspace":
            credit_body.append(tuple(cred_buffer))
            cred_buffer = []
            continue
        cred_buffer.append(line)
    # Flush remaining.
    credit_body.append(tuple(cred_buffer))

    credit = sp.credits_body(title, volume, color_edition, edition, tuple(credit_body))
    credit = st.File(base_dir / "credits.xhtml", credit, init_read=False)

    # Get the contents.
    arc = get_latex_master_section(master.content, "arc")
    contents = sp.toc(arc, find_contents_from_master(master))
    contents = st.File(base_dir / "contents.xhtml", contents, init_read=False)

    return insert, credit, contents


def find_contents_from_master(master: st.File) -> tuple[tuple[str, str]]:
    """
    Find the contents from the master file.

    :param master: The master file.
    :return: tuples of file_name, chapter_name.
    """
    contents_raw = get_latex_master_section(master.content, "contents")
    # Package file name and chapter title into tuples.
    # \contentsref{file name}{chapter title}
    contents_list = []
    for line in contents_raw.splitlines():
        line = line.strip()
        if not line:
            continue
        content_match = re.match(r"\\contentsref{(.+?)}{(.+?)}", line)
        file_name = content_match.group(1)
        chapter_title = content_match.group(2)
        contents_list.append((file_name, chapter_title))

    # noinspection PyTypeChecker
    return tuple(contents_list)


def latex_paragraph_to_html(tex: str) -> str:
    """
    Convert latex to basic html.

    :param tex: The latex to convert.
    :return: The converted html.
    """

    # Convert context-free elements.
    tex = re.sub(r"\\textbf{(.+?)}", r"<b>\1</b>", tex)
    tex = re.sub(r"\\emph{(.+?)}", r"<em>\1</em>", tex)
    tex = re.sub(r"\\sout{(.+?)}", r"<s>\1</s>", tex)
    tex = re.sub(r"\\textsuperscript{(.+?)}", r"<sup>\1</sup>", tex)
    tex = re.sub(r"\\href{(.+?)}{\\uline{(.+?)}}", r'<a href="\1" class="hlink">\2</a>', tex)
    return tex


def resolve_symbols(tex: str) -> str:
    """
    Resolve symbols in the latex.

    :param tex:
    :return:
    """
    tex = re.sub(r"\\ldots{}", r"…", tex)
    tex = re.sub(r"---", r"—", tex)
    tex = re.sub("``", r"“", tex)
    tex = re.sub("''", r"”", tex)
    tex = re.sub("`", r"‘", tex)
    tex = re.sub("'", r"’", tex)
    tex = re.sub(r"\\_", r"_", tex)
    tex = re.sub(r"\\&", r"&amp;", tex)
    tex = re.sub(r"\\\\%HTML-list-break", "</p><p>", tex)
    tex = re.sub(r"\\%", r"%", tex)
    tex = re.sub(r"\\~", r"~", tex)
    tex = re.sub(r"\\\\", r"<br/>", tex)
    return tex


def chapter_latex_to_basic_html(tex: str, figure_dir: str, title_card_dir: str) -> str:
    """
    Convert chapter-specific elements.
    Parse line by line.

    :param tex:
    :param figure_dir: The directory containing the figures.
    :param title_card_dir: The directory containing the title cards.
    :return: html
    """

    # Resolve symbols.
    tex = resolve_symbols(tex)

    # Split into lines.
    lines = tex.splitlines(keepends=False)
    html = []

    # Flags.
    text_break = False
    no_indent = False
    labeled_list = False
    current_paragraphs: list[str] = []
    label_open = False

    def flush_paragraphs():
        nonlocal current_paragraphs
        nonlocal html
        nonlocal text_break
        nonlocal no_indent

        paragraph = " ".join(current_paragraphs)
        if paragraph:
            html.append(sp.paragraph(latex_paragraph_to_html(paragraph), text_break, no_indent))
        current_paragraphs = []
        text_break = False
        no_indent = False

    for line in lines:
        if line == "":
            # Paragraph break.
            if current_paragraphs:
                flush_paragraphs()
            continue

        if line.startswith("\\"):
            if match := re.match(r"\\(fullpageimage|exactfitimage)(\[(.*?)])?{(.+?)}", line):
                html.append(sp.image_tag(f"{match.group(4)}", match.group(3)))
            elif match := re.match(r"\\(mangaheader)(\[(.*?)])?{(.+?)}", line):
                html.append(sp.image_tag(f"{match.group(4)}", match.group(3), is_manga=True))
            elif match := re.match(r"\\chapterheader{(.+)}{(.+)}{(.+)}", line):
                # Chapter header.
                html.append(
                    sp.chapter_header(
                        chapter_name=match.group(2),
                        chapter_title=match.group(3),
                        chapter_link=match.group(1),
                        title_card_dir=title_card_dir,
                    )
                )
            elif re.match(r"\\afterwordheader", line):
                # Afterword header.
                html.append(sp.afterword_header())
            elif re.match(r"\\hardscenebreak", line):
                # Hard scene break.
                html.append(sp.hard_scene_break(figure_dir))
                text_break = True
            elif re.match(r"\\softscenebreak", line):
                # Soft scene break.
                html.append(sp.soft_scene_break(figure_dir))
                text_break = True
            elif re.match(r"\\textbreak", line):
                # Text break.
                text_break = True
            elif match := re.match(r"\\noindent (.*)", line):
                # No indent.
                current_paragraphs.append(match.group(1))
                # html.append(sp.paragraph(latex_paragraph_to_html(match.group(1)), text_break, True))
                # text_break = False
                no_indent = True
            elif match := re.match(r"\\begin{itemize}(\[.*?] % HTML-HINT: LABELED)?", line):
                # Flush any paragraphs.
                flush_paragraphs()
                # Itemize or labelize. Use the explicit magic hint from the latex source to decide.
                labeled_list = match.group(1) is not None
                html.append(sp.begin_list(labeled_list))
                label_open = False
                text_break = False  # Reset text break. HTML always has padding.
            elif re.match(r"\\end{itemize}", line):
                # End itemize.
                flush_paragraphs()
                html.append(sp.end_list_label(labeled_list))
                html.append(sp.end_list(labeled_list))
                labeled_list = False
                label_open = False
            elif match := re.match(r"\\item(\[(.*?)])? (.+)", line):
                if label_open:
                    html.append(sp.end_list_label(labeled_list))
                # Item. If it has a label, make a data list tag.
                label_open = True
                html.append(
                    sp.list_item_start(
                        latex_paragraph_to_html(match.group(2))
                        if match.group(2) is not None
                        else None,
                    )
                )
                current_paragraphs.append(match.group(3))
            elif re.search(r"^\\(textbf|emph|sout)", line):
                # Bold or italic or strikeout.
                current_paragraphs.append(line)
            else:
                logger.error(f"Unknown command: {line}")
        elif line.startswith("<"):
            # HTML tag.
            html.append(line)
        else:
            # Paragraph.
            current_paragraphs.append(line)

    flush_paragraphs()

    return "\n".join(html)


def rend_footnotes_epub(binder: st.FileBinder) -> st.File:
    """
    Rend footnotes from each section.
    Place them all in a single File, linking accordingly.

    :param binder: Given files.
    :return: A File for the footnotes.
    """

    # Collect the footnotes from all the sections in order.
    # Replace them with sequentially numbered back references.
    # This data structure holds tuples of footnote number, file back reference, and footnote text.
    footnotes: list[tuple[int, str, str]] = []

    for file in binder.sections:
        # Footnotes have the form \footnote{...}.
        # We want to replace them with a back reference snippet.
        # We also want to collect the footnote text.
        for match in re.finditer(r"(\\footnote{(.+?)})", file.content):
            footnote_html = sp.footnote_text(match.group(2))
            footnotes.append(
                (len(footnotes) + 1, chapter_name_to_ref(file.path.stem), footnote_html)
            )
            file.content = file.content.replace(
                match.group(1), sp.footnote_reference(len(footnotes))
            )

    # Create the footnotes file.
    footnote_body = sp.footnote_body(footnotes)
    return st.File(Path("notes.xhtml"), footnote_body, init_read=False)


def relink_image_prefixes(html: str, image_subdir: Path) -> str:
    """
    Relink images in the html.
    Change the parent directory the images are to be found in,
    but preserve whatever subdirectory they are in.

    :param html: Given html.
    :param image_subdir: The image subdirectory.
    :return: The html with the image prefixes changed.
    """

    # Find all the images.
    html = re.sub(r"src=\"(.*?)\"", lambda match: f'src="/{image_subdir / match.group(1)}"', html)

    return html


def relink_colored_image_paths(
    html: str, base_dir: Path, image_dir: str, colored_image_dir: str
) -> str:
    """
    If a colored image is available, insert a smart link to it.
    This smart link toggles between the colored and black and white versions in slime reader.

    :param html: Given html.
    :param base_dir: Base markdown project directory.
    :param image_dir: Image directory.
    :param colored_image_dir: Colored image directory.
    :return: The html with the smart links.
    """

    def gen_smart_link(match: re.Match) -> str:
        """
        Generate a smart link to a colored image, if it exists.

        :param match: The match object.
        :return: The smart link or original match.
        """
        color_path = check_image_suffixes(base_dir / colored_image_dir / match.group(2))
        # logger.debug(f"Checking for colored image: {color_path}")
        if color_path is not None:
            logger.debug(f"Found colored image: {color_path}")
            repl = (
                f'src="{match.group(1)}{{: this.app.otherConfigs.coloredIllustrations ? '
                f"'{colored_image_dir}/{color_path.name}' : '{image_dir}/{match.group(2)}' :}}"
                f'|{{otherConfigs.coloredIllustrations}}|"'
            )
            return repl
        else:
            return match.group(0)

    # Find all the images in the IMG subdir, and if a file with the same name exists
    # in the COLORED subdir, insert a smart link.
    html = re.sub(
        rf"src=\"(.*?){image_dir}/(.*?)\"",
        gen_smart_link,
        html,
    )

    return html


def escape_footnote(footnote_text: str) -> str:
    """
    Escape footnote text to make it html safe.

    :param footnote_text: The footnote text containing html and optionally \\ to indicate a line break.
    :return: A plain text string.
    """

    # Escape the footnote text by removing all tags.
    footnote_text = re.sub(r"<[^>]*>", "", footnote_text)
    footnote_text = re.sub(r"\\", " ", footnote_text)
    footnote_text = re.sub(r"\"", "'", footnote_text)

    return footnote_text


def get_latex_master_section(tex: str, section: str) -> str:
    """
    Grab a section from the latex master file.
    These sections are evey line between
    % BEGIN [section]
    and
    % END [section]

    :param tex: The latex master file.
    :param section: The section to grab.
    :return: The section.
    """

    section = section.upper()

    # Get the section.
    section = tex.split(f"% BEGIN [{section}]")[1].split(f"% END [{section}]")[0].strip()

    return section


def master_get_includes(master: st.File) -> list[str]:
    """
    Get the includes from the master file.

    :param master: The master file.
    :return: A list of the includes in the master file.
    """

    # Master section.
    master_section = get_latex_master_section(master.content, "includes")

    # Get the includes from the master file.
    includes = re.findall(r"\\input{(.+)}", master_section)

    return includes


def master_get_simple_book_title(master: st.File) -> str:
    """
    Combine the title and volume into one string.

    :param master: The master file.
    :return: The simple book title.
    """

    # Master section.
    title = get_latex_master_section(master.content, "title")
    volume = get_latex_master_section(master.content, "volume")

    return f"{title}, {volume}"


def get_cover_image_name(master: st.File) -> str:
    """
    Get the cover image name from the master file.

    :param master: The master file.
    :return: The cover image name.
    """

    cover_section = get_latex_master_section(master.content, "cover")
    cover_image = re.search(r"\\fullpageimage{.*?/(.+?)}", cover_section).group(1)

    return cover_image


def generate_cover(binder: st.FileBinder) -> st.File:
    """
    Grab the cover image from the master.
    :param binder: File binder.
    :return: cover file.
    """
    cover_image = get_cover_image_name(binder.master)

    cover_html = sp.cover_page(cover_image)

    return st.File(Path("cover.xhtml"), cover_html, init_read=False)


def gather_toc_nav_sections(binder: st.FileBinder) -> list[tuple[str, str]]:
    """
    Collect the basic data required to build the EPUB3 standard nav file.

    :param binder: File binder.
    :return: A list of tuples containing the chapter file name and chapter title.
    """
    # The contents to list, expects a list of tuples of the form (section title, file name).
    content_sections: list[tuple[str, str]] = [
        ("Cover", "insert.xhtml"),
        ("Contents", "contents.xhtml"),
    ]

    # Add the sections.
    for file_name, chapter_title in find_contents_from_master(binder.master):
        content_sections.append((chapter_title, file_name + ".xhtml"))

    content_sections.append(("Notes", "notes.xhtml"))

    # Generate the tags using the tag factory.
    return content_sections


def rend_footnotes_slime_reader(html: str) -> str:
    """
    Render the footnotes in the slime reader.
    This inserts them inline using a custom Slime Reader tag.

    :param html: The html to render.
    :return: The rendered html.
    """

    # Find all the latex footnotes and insert slime reader footnotes.
    html = re.sub(
        r"\\footnote{(.+?)}",
        lambda match: sp.make_slime_reader_footnote(escape_footnote(match.group(1))),
        html,
    )

    return html


def relink_slime_reader_toc(html: str) -> str:
    """
    Relink the toc in the slime reader.

    :param html: The html to relink.
    :return: The relinked html.
    """

    # Change the file reference to an anchor reference.
    html = re.sub(r"href=\"(.+?)\.xhtml\"", lambda match: f'href="#{match.group(1)}"', html)

    return html


def censor_footnotes_img_tag(html: str) -> tuple[str, dict[str, str]]:
    """
    Censor the footnotes and image tags by replacing them with an identifier.
    That way they won't be caught up in the term replacement madness.
    Footnote text specifically is censored: "data-hover-text="footnote_html" onclick"
    -> "data-hover-text="[mask::id]" onclick"

    Image tag is censored: <img .../> or <img ...></img>
    -> [mask::id]

    Use sequential ids to avoid collisions.

    This is important because these texts are plain text that may not contain html tags, which the
    Termer would insert.

    :param html:
    :return: the censored html and a dict, mapping the id to the uncensored text.
    """

    decensor_patch = {}

    def censor(match):
        current_id = f"[mask::{len(decensor_patch)}]"
        decensor_patch[current_id] = match.group(0)
        return current_id

    html = re.sub(r'data-hover-text="(.+?)"\s+?onclick', censor, html)
    html = re.sub(r"<img.+?/>|<img.+?></img>", censor, html)

    logger.debug(f"Protected {len(decensor_patch)} footnotes and image tags.")

    return html, decensor_patch


def decensor_footnotes_img_tag(html: str, decensor_patch: dict[str, str]) -> str:
    """
    Decensor the footnotes and image tags by replacing the identifiers with the uncensored text.

    :param html: The html to decensor.
    :param decensor_patch: The decensor patch.
    :return: The decensored html.
    """

    for current_id, current_text in decensor_patch.items():
        html = html.replace(
            current_id, current_text, 1
        )  # Only look for the first occurrence, since they are unique.

    return html


def make_terms_swappable(html: str, pattern: str, terms: dict[str, st.Term]):
    """
    Make terms swappable.
    Use the pattern to find terms to swap. Replace them with the swap snippet, if
    they are upper case, or if they are lower case and terms_case_sensitive[term] is True.

    :param html: The html to make terms swappable.
    :param pattern: The pattern to match.
    :param terms: A dictionary of terms to swap, containing the reference capitalization and case sensitivity.
    :return: The html with swappable terms.
    """

    # Censor the footnotes to protect them from the term replacement madness.
    html, decensor_patch = censor_footnotes_img_tag(html)

    # Pad the pattern with word boundaries, and allow for plurals.
    pattern = rf"\b({pattern})(s?)\b"

    # Split the html into lines, for more efficient replacement.
    # html_lines = html.splitlines()

    # Find all the terms.
    count = 0

    def both_capitalized(a: str, b: str) -> bool:
        return a[0].isupper() and b[0].isupper()

    def figure_out_replacement(match):
        nonlocal count
        current_word = str(match.group(1))
        # We want to reject the match if capitalization doesn't match and the term is case sensitive.
        try:
            if (
                not both_capitalized(current_word, terms[current_word.lower()].term)
                and terms[current_word.lower()].case_sensitive
            ):
                return match.group(0)
        except KeyError as e:
            logger.exception(e)
            logger.error(f"Term {current_word} not found.")

        count += 1
        # Return the replacement tag with the correct capitalization coercion for whatever replacement.
        return sp.slime_reader_swappable_term(
            found_term=current_word,
            real_term=terms[current_word.lower()].term,
            case_sensitive=terms[current_word.lower()].case_sensitive,
        ) + (match.group(2) if match.group(2) else "")

    html = re.sub(pattern, figure_out_replacement, html, flags=re.IGNORECASE)

    # Undo the censorship.
    html = decensor_footnotes_img_tag(html, decensor_patch)

    logger.info(f"Marked {count} terms for swapping.")

    return html


def add_line_counters(html: str) -> str:
    """
    Add line counters to the html.
    Each paragraph receives an id of the form "line_<line number>",
    numbered sequentially from the start of the document.

    :param html: The html to add line counters to.
    :return: The html with line counters.
    """

    soup = bs4.BeautifulSoup(html, "html.parser")

    for i, tag in enumerate(soup.find_all(["p"])):
        tag["id"] = f"line_{i}"

    return str(soup)


def fix_terms_eating_spaces(html):
    """
    Slip spaces before selectable terms into the previous tag, if they are adjacent.
    `</em> <span` -> ` </em><span`
    This is a workaround for a bug in CSS related to inline blocks.
    Apply this fix for all tags that are inline blocks.

    :param html: The html to fix.
    :return: The fixed html.
    """
    logger.info("Fixing terms eating spaces.")
    return re.sub(r"</(em|strong|strike)> <span", r" </\1><span", html)


def add_terms_hash(html: str, terms_file: Path | None) -> str:
    """
    Calculate the md5 hash of the terms file and add it to the top of the html in a comment.

    :param html: The html to add the hash to.
    :param terms_file: The terms file. If None, write a placeholder hash.
    :return: The html with the hash.
    """

    if terms_file is None:
        terms_hash = "None"
    else:
        terms_hash = hashlib.md5(terms_file.read_bytes()).hexdigest()
    logger.info(f"Terms hash: {terms_hash}")

    return sp.term_hash_comment(terms_hash) + html
