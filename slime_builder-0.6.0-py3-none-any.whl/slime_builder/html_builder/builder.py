from importlib import resources
import json
import re
import time
from pathlib import Path
import datetime

from logzero import logger
from ebooklib import epub
import subprocess
from concurrent.futures import ThreadPoolExecutor

import slime_builder.html_builder.processors as pr
import slime_builder.html_builder.snippets as sp
import slime_builder.structures as st
from slime_builder.html_builder import stylesheets
from slime_builder.helpers import chapter_name_to_ref


def latex_to_html_primitive(
    base_dir: Path,
    figure_dir: str,
    title_card_dir: str,
    suppress_failed_color: bool = False,
    debug: bool = False,
) -> st.FileBinder | None:
    """
    Gather the tex files from the base path and convert them into
    primitive html files.

    :param base_dir: The base directory containing all files.
    :param figure_dir: The directory containing the figures.
    :param title_card_dir: The directory containing the title cards.
    :param suppress_failed_color: If true, do not raise an error if the colored edition is requested but the colored
        images are missing.
    :param debug: If true, do not clean up the output directory.
    :return: A binder containing all the files in memory, or None if skipping.
    """

    # Start timer.
    t_start = time.time()

    # Get the tex files.
    tex_files = [st.File(p) for p in base_dir.glob("*.tex")]

    logger.debug(f"Found {len(tex_files)} tex files:")
    for f in tex_files:
        logger.debug(f"File: {f.path.name}")

    # Sort files into binder.
    binder = st.FileBinder()
    for f in tex_files:
        if f.path.name == "Master.tex":
            binder.master = f
        else:
            binder.sections.append(f)
    # Ensure we have a master file.
    if binder.master is None and suppress_failed_color:
        return None
    # Sort files by Master order. To do this, obtain the order from the master file.
    master_includes = pr.master_get_includes(binder.master)
    binder.sections.sort(key=lambda x: master_includes.index(x.path.name))

    # Info.
    book_title = pr.master_get_simple_book_title(binder.master)
    info_str = f"Binder: {book_title}\nMaster: " + binder.master.path.name + "\nSections:\n"
    for s in binder.sections:
        info_str += " - " + s.path.name + "\n"
    logger.info(info_str)

    # Convert the files.
    for f in binder.sections:
        f.content = pr.chapter_latex_to_basic_html(f.content, figure_dir, title_card_dir)

    # Convert the master file.
    # Split it into 3 files:
    # - the insert
    # - the credit
    # - the contents
    insert, credit, contents = pr.master_latex_to_html(
        base_dir, binder.master, figure_dir, title_card_dir
    )

    binder.sections = [insert, credit, contents] + binder.sections

    # End timer and display in ms.
    t_end = time.time()
    logger.info(f"Primitive conversion took {round((t_end - t_start) * 1000)} ms.")

    return binder


def html_primitive_to_epub(
    base_dir: Path,
    colored_edition: bool,
    binder: st.FileBinder,
    output_dir_name: str,
    image_dir: str,
    colored_image_dir: str,
    figure_dir: str,
    title_card_dir: str,
    debug: bool = False,
    skip_other_formats: bool = False,
    suppress_missing_color: bool = False,
):
    """
    Use the primitive html files to generate epub-ready files.

    :param base_dir: The base directory containing all files.
    :param colored_edition: If true, use the colored edition.
    :param binder: The binder to use.
    :param output_dir_name: The name of the output directory.
    :param image_dir: The directory containing the images.
    :param colored_image_dir: The directory containing the colored images.
    :param figure_dir: The directory containing the figures.
    :param title_card_dir: The directory containing the title cards.
    :param debug: If true, do not clean up the output directory.
    :param skip_other_formats: If true, do not convert to additional ebook formats (mobi, azw3).
    :param suppress_missing_color: If true, silently abort if the image directory is missing.
    :return: A binder containing all the files in memory.
    """
    # Check if the image directory exists. It's possible that we're building
    # a colored edition without having colored images.
    img_dir = image_dir if not colored_edition else colored_image_dir
    # Check if the image directory exists.
    if not (base_dir / img_dir).exists():
        if suppress_missing_color and colored_edition:
            logger.warning("Colored edition requested, but no colored images found. Skipping.")
            return
        else:
            raise FileNotFoundError(f"Image directory {img_dir} is missing.")

    # Rend the footnotes for epub export.
    notes = pr.rend_footnotes_epub(binder)
    binder.sections.append(notes)

    # Wrap in headers.
    book_title = pr.master_get_simple_book_title(binder.master)
    # for f in binder.sections[:3]:
    #     f.content = sp.wrap_preamble(f.content)

    for f in binder.sections[3:]:
        f.content = sp.wrap_story(f.content)

    # Generate a toc_ncx body.
    toc_ncx = pr.gather_toc_nav_sections(binder)

    img_dir = base_dir / img_dir
    fallback_img_dir = base_dir / image_dir
    figure_dir = base_dir / figure_dir
    title_card_dir = base_dir / title_card_dir
    built_epub_path = build_epub_from_binder(
        base_dir,
        binder,
        output_dir_name,
        book_title,
        colored_edition,
        toc_ncx,
        img_dir,
        fallback_img_dir,
        figure_dir,
        title_card_dir,
    )

    if built_epub_path is None:
        logger.error("Failed to build epub.")
        return

    # Convert to mobi and azw3.
    if not skip_other_formats:
        # Use threading to run in parallel.
        with ThreadPoolExecutor(max_workers=2) as executor:
            executor.submit(convert_epub_to_format, built_epub_path, "mobi")
            executor.submit(convert_epub_to_format, built_epub_path, "azw3")


def build_epub_from_binder(
    base_dir: Path,
    binder: st.FileBinder,
    output_dir_name: str,
    book_title: str,
    colored_edition: bool,
    toc_nav: list[tuple[str, str]],
    img_dir: Path,
    img_dir_fallback: Path,
    figure_dir: Path,
    title_card_dir: Path,
) -> Path | None:
    """
    Build an epub file from the binder.

    :param base_dir: The base directory containing all files.
    :param binder: The binder to use.
    :param output_dir_name: The name of the output directory.
    :param book_title: The title of the book.
    :param colored_edition: Indicator for the file name.
    :param toc_nav: The table of contents.
    :param img_dir: The image directory.
    :param img_dir_fallback: The fallback image directory.
    :param figure_dir: The figure directory.
    :param title_card_dir: The title card directory.
    :return: The path to the epub file, or None if the epub file was not created.
    """

    book = epub.EpubBook()

    # Set metadata.
    book.set_title(book_title)
    book.set_language("en")
    book.add_author("Fuse")
    book.add_metadata("DC", "publisher", "Tensurafan")
    book.add_metadata("DC", "date", datetime.datetime.now().strftime("%Y-%m-%d"))

    # Add CSS files.
    with resources.files(stylesheets) as stylesheets_dir:
        stylesheet_css = stylesheets_dir / "stylesheet.css"
        stylesheet = epub.EpubItem(
            uid="stylesheet",
            file_name="stylesheet.css",
            media_type="text/css",
            content=stylesheet_css.read_bytes(),
        )
        page_styles_css = stylesheets_dir / "page_styles.css"
        page_styles = epub.EpubItem(
            uid="page_styles",
            file_name="page_styles.css",
            media_type="text/css",
            content=page_styles_css.read_bytes(),
        )
    book.add_item(stylesheet)
    book.add_item(page_styles)

    # Keep track of the images we've already added.
    img_names_added = set()

    # Add the cover.
    cover_file = pr.get_cover_image_name(binder.master)
    book.set_cover(
        file_name=str((img_dir_fallback / cover_file).relative_to(base_dir)),
        content=(base_dir / img_dir_fallback / cover_file).read_bytes(),
        create_page=False,
    )
    img_names_added.add(cover_file)

    chapters = []
    # Add the chapters.
    for f in binder.sections:
        # Make file names epub-friendly.
        fname = chapter_name_to_ref(f.path.stem + ".xhtml")
        chapter = epub.EpubHtml(
            title=book_title, file_name=fname, content=f.content, media_type="application/xhtml+xml"
        )
        # Link the stylesheets to the chapter.
        chapter.add_item(stylesheet)
        chapter.add_item(page_styles)

        book.add_item(chapter)
        chapters.append(chapter)

    # Add the rest of the images.
    def add_image_dir(path: Path):
        for img in path.iterdir():
            if img.name not in img_names_added:
                book.add_item(
                    epub.EpubItem(
                        uid=img.name,
                        file_name=str((path / img.name).relative_to(base_dir)),
                        content=img.read_bytes(),
                    )
                )
                img_names_added.add(img.name)

    # First, try to add the images from the selected image directory.
    add_image_dir(img_dir)
    # If we're missing images, try to add them from the fallback image directory.
    add_image_dir(img_dir_fallback)
    # Add the figures and title cards.
    add_image_dir(figure_dir)
    add_image_dir(title_card_dir)

    # Add the spine.
    # noinspection PyTypeChecker
    book.spine = chapters + ["nav"]

    # Add the table of contents.
    book.toc = [
        epub.Link(chapter_file, chapter_title, pr.chapter_name_to_ref(chapter_title))
        for chapter_title, chapter_file in toc_nav
    ]
    # Add the navigation files.
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())

    # Write the epub.
    # Remove the leading "% " from the volume string.
    volume_str = pr.get_latex_master_section(binder.master.content, "metadata-volume-string")[2:]
    volume_num = re.search(r"\d+([.,]\d+)?", book_title).group(0)

    name_suffix = ""
    if colored_edition:
        name_suffix = " - Colored Edition"
    file_path = base_dir / output_dir_name / f"{volume_str} {volume_num}{name_suffix}.epub"
    file_path.parent.mkdir(exist_ok=True, parents=True)
    try:
        epub.write_epub(file_path, book)
    except Exception as e:
        logger.error(f"Failed to write epub file {file_path}")
        logger.exception(e)
        return None

    logger.info(f"Done writing epub {file_path}.")
    return file_path


def html_primitive_to_slime_reader(
    base_dir: Path,
    terms_file: Path | None,
    binder: st.FileBinder,
    image_dir: str,
    colored_image_dir: str,
    reader_html_dir: str,
    reader_img_dir: str,
    debug: bool = False,
):
    """
    Use the primitive html files to generate slime-reader-ready files.

    :param base_dir: The base directory containing all files.
    :param terms_file: The path to the terms file. If None, term replacement is skipped.
    :param binder: The binder to use.
    :param image_dir: The image directory.
    :param colored_image_dir: The colored image directory.
    :param reader_html_dir: The directory to write the html files to.
    :param reader_img_dir: The directory to write the image files to.
    :param debug: If true, do not clean up the output directory.
    :return: A binder containing all the files in memory.
    """

    # Timer start.
    t_start = time.time()

    # Merge all files into one html string.
    html = binder.merge_all()

    # Get the mangled book filename from the volume number.
    volume = pr.get_latex_master_section(binder.master.content, "volume")
    # Remove the leading "% " from the volume string.
    volume_str = pr.get_latex_master_section(binder.master.content, "metadata-volume-string")[2:]
    volume_num = re.search(r"\d+([.,]\d+)?", volume).group(0)
    # Grab the first character of the volume string, which is usually Volume, but can be overridden (e.g. with Booklet).
    filename = volume_str.lower()[0] + volume_num + ".html"
    # Create output dirs.
    output_dir = (base_dir / reader_html_dir).resolve()
    output_dir.mkdir(exist_ok=True)

    # Re-link to the images in the source directory to prevent duplicates.
    img_dir_rel = Path(reader_img_dir.format(volume_str=volume_str, volume_number=volume_num))
    html = pr.relink_image_prefixes(html, img_dir_rel)
    html = pr.relink_colored_image_paths(
        html, base_dir, image_dir=image_dir, colored_image_dir=colored_image_dir
    )

    # Re-link file references in the table of contents.
    html = pr.relink_slime_reader_toc(html)

    # Render the footnotes.
    html = pr.rend_footnotes_slime_reader(html)

    # Load the terms.
    if terms_file is not None:
        pattern, terms = load_terms(terms_file)
        html = pr.make_terms_swappable(html, pattern, terms)
        # Fix terms eating spaces.
        html = pr.fix_terms_eating_spaces(html)

    # Add the hash of the terms file to the html.
    html = pr.add_terms_hash(html, terms_file)

    # Add line counters.
    html = pr.add_line_counters(html)

    # End timer and display in ms.
    t_end = time.time()
    logger.info(f"Slime reader conversion took {round((t_end - t_start) * 1000)} ms.")

    # Write the files.
    output_file = output_dir / filename
    output_file.write_text(html)
    logger.info(f"Slime Reader file written to {output_file}.")


def load_terms(terms_file: Path) -> tuple[str, dict[str, st.Term]]:
    """
    Load the terms json file.

    :param terms_file: The path to the terms file.
    :return: A tuple containing the pattern and a dict for term: Term.
    """
    term_json = json.loads(terms_file.read_text())
    pattern = term_json["pattern"]
    terms_raw = term_json["terms"]
    terms = {}
    # Flatten the terms value from a dict to simple the value of the dict["caseSensitive"].
    # Also make the keys lowercase.
    for k, v in terms_raw.items():
        if k.lower() in terms:
            logger.warning(f"Duplicate term {k.lower()}.")
            # Check if one is case sensitive while the other is not.
            if terms[k.lower()].case_sensitive != v["caseSensitive"]:
                logger.warning(
                    f"Duplicate term {k.lower()} has different case sensitivity. Making term case insensitive."
                )
                terms[k.lower()] = st.Term(k, False)
            continue
        terms[k.lower()] = st.Term(k, v["caseSensitive"])

    return pattern, terms


def convert_epub_to_format(epub_path: Path, extension: str) -> bool:
    """
    Convert an epub file to a different format.

    :param epub_path: The path to the epub file.
    :param extension: The extension of the output file.
    :return: True if the conversion was successful, False otherwise.
    """
    # Ensure the extension is valid. It must start with a dot and not be empty.
    if not extension:
        logger.error("Extension must not be empty.")
        return False
    if extension[0] != ".":
        extension = "." + extension

    logger.info(f"Converting {epub_path} to {extension}.")
    output_path = epub_path.with_suffix(extension)

    # Delete an existing file, so that we can check if the conversion was successful.
    if output_path.is_file():
        output_path.unlink()

    # Run the command but only give the output if there was an error.
    try:
        output = subprocess.check_output(
            ["ebook-convert", str(epub_path), str(output_path)],
            stderr=subprocess.STDOUT,
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to convert {epub_path} to {extension}.")
        logger.error(e.output.decode("utf-8"))
        return False
    except Exception as e:
        logger.error(f"Failed to convert {epub_path} to {extension}.")
        logger.exception(e)
        return False

    # Check if the file was created.
    if not output_path.exists():
        logger.error(f"Failed to convert {epub_path} to {extension}.")
        if output is not None:
            logger.error(output.decode("utf-8"))
        return False

    logger.info(f"Done converting {epub_path} to {extension}.")
    return True
